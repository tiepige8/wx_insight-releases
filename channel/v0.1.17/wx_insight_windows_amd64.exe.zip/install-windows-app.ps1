﻿param(
    [string]$InstallRoot = $PSScriptRoot,
    [string]$ExeName = 'wx_channel.exe',
    [string]$Python = '',
    [string]$SessionUsername = ''
)

$ErrorActionPreference = 'Stop'
$appTaskName = 'wx_insight_app'
$workerTaskName = 'wx_insight_inbox_worker'
$exe = Join-Path $InstallRoot $ExeName
$launcher = Join-Path $InstallRoot 'start-wx-insight.ps1'
$workerInstaller = Join-Path $InstallRoot 'install-inbox-worker.ps1'
$workerRoot = Join-Path $InstallRoot 'inbox-worker'
$sessionsPath = Join-Path $workerRoot 'sessions.txt'

if (-not (Test-Path -LiteralPath $exe)) {
    throw "主程序不存在：$exe"
}
if (-not (Test-Path -LiteralPath $launcher)) {
    throw "启动脚本不存在：$launcher"
}
if (-not (Test-Path -LiteralPath $workerInstaller)) {
    throw "监听器安装脚本不存在：$workerInstaller"
}

if (-not [string]::IsNullOrWhiteSpace($SessionUsername)) {
    New-Item -ItemType Directory -Force -Path $workerRoot | Out-Null
    [System.IO.File]::WriteAllText($sessionsPath, $SessionUsername.Trim() + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))
}
if (-not (Test-Path -LiteralPath $sessionsPath)) {
    throw '尚未配置监听会话。请传入 -SessionUsername wxid_xxx，避免误监听全部微信对话。'
}
$configuredSessions = @(
    [System.IO.File]::ReadAllLines($sessionsPath, [System.Text.Encoding]::UTF8) |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ -and -not $_.StartsWith('#') }
)
if ($configuredSessions.Count -eq 0) {
    throw 'sessions.txt 没有有效会话，请至少填写一个 wxid_xxx。'
}

$escapedExe = $exe.Replace("'", "''")
$escapedRoot = $InstallRoot.Replace("'", "''")
$command = "Start-Process -FilePath '$escapedExe' -WorkingDirectory '$escapedRoot' -WindowStyle Hidden -Wait"
$arguments = '-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -Command "' + $command + '"'
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arguments -WorkingDirectory $InstallRoot
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 10 -RestartInterval (New-TimeSpan -Minutes 1) -MultipleInstances IgnoreNew
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Highest
Register-ScheduledTask -TaskName $appTaskName -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force | Out-Null

& $workerInstaller -InstallRoot $InstallRoot -Python $Python

$shell = New-Object -ComObject WScript.Shell
$shortcutTargets = @(
    (Join-Path ([Environment]::GetFolderPath('Desktop')) '微信洞察.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) '微信洞察.lnk')
)
$shortcutArguments = '-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + $launcher + '" -InstallRoot "' + $InstallRoot + '"'
foreach ($shortcutPath in $shortcutTargets) {
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = 'powershell.exe'
    $shortcut.Arguments = $shortcutArguments
    $shortcut.WorkingDirectory = $InstallRoot
    $shortcut.IconLocation = "$exe,0"
    $shortcut.Description = '启动微信洞察、微信视频号监听和数据页面'
    $shortcut.Save()
}

Start-ScheduledTask -TaskName $appTaskName
Write-Host "WINDOWS_APP_OK task=$appTaskName worker=$workerTaskName shortcut=微信洞察"

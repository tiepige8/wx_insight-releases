(() => {
    'use strict';

    const state = {
        query: '',
        author: '',
        product: 'all',
        ad: 'all',
        sort: 'published_desc',
        days: 30,
        page: 1,
        pageSize: 10,
        totalPages: 1,
        items: [],
        selectedId: null,
        loading: false,
        searchTimer: null,
        toastTimer: null,
        requestController: null,
        automationTimer: null,
        automationFormHydrated: false,
        automationBusy: false,
        automationControlBusy: false,
        feedImportController: null,
        searchImportBusy: false,
        searchImportController: null,
        accountDownloadBusy: false,
        accountDownloadController: null,
        accountDownloadAccounts: [],
        accountDownloadSelectedAccount: null,
        accountDownloadItems: [],
        accountDownloadSelectedIds: new Set(),
        accountDownloadNextMarker: '',
        accountDownloadHasMore: false,
        accountDownloadBatchTimer: null,
        liveSearchBusy: false,
        liveSearchKeyword: '',
        liveSearchNextMarker: '',
        liveSearchHasMore: false,
        liveSearchItems: [],
        liveSearchProductLoads: new Set(),
        liveLibraryTargets: [],
        liveLibrarySelectedTarget: null,
        liveLibraryTimer: null,
        productInspectionTimer: null,
        productInspectionMessageElement: null,
        mediaTimer: null,
        autoTranscriptionRequested: new Set(),
        playerRefreshAttempted: false,
        playerRecordId: null,
    };

    const elements = {};

    function $(id) {
        return document.getElementById(id);
    }

    function cacheElements() {
        [
            'collector-state', 'search-input', 'author-filter', 'product-filter', 'ad-filter', 'days-filter', 'sort-filter',
            'metric-videos', 'metric-engagement', 'metric-average', 'metric-pending',
            'content-rows', 'loading-state', 'empty-state', 'result-count',
            'page-status', 'previous-page', 'next-page', 'refresh-button',
            'detail-panel', 'detail-placeholder', 'detail-content', 'detail-author',
            'detail-name', 'detail-date', 'detail-score', 'score-ring', 'detail-likes',
            'detail-comments', 'detail-favorites', 'detail-forwards', 'detail-judgement',
            'signal-list', 'product-section', 'product-title', 'product-meta', 'product-link',
            'media-section', 'media-link-state', 'copy-video-link', 'download-video',
            'play-video', 'transcribe-video', 'media-status',
            'transcript-section', 'transcript-text', 'copy-transcript',
            'player-modal', 'player-close', 'player-title', 'insight-player', 'player-status',
            'comment-count', 'keyword-list', 'comment-empty', 'toast',
            'export-button', 'nav-export', 'collapse-sidebar', 'mobile-menu', 'detail-close',
            'nav-update', 'update-modal', 'update-close-icon', 'update-close', 'update-install',
            'update-version', 'update-message', 'update-notes',
            'nav-auto-browse', 'nav-stop-auto-browse', 'automation-modal', 'automation-close-icon', 'automation-close',
            'automation-state', 'automation-connection', 'automation-connection-title',
            'automation-connection-message', 'automation-progress-text',
            'automation-progress-bar', 'automation-message', 'automation-target',
            'automation-min-dwell', 'automation-max-dwell', 'automation-start',
            'automation-pause', 'automation-resume', 'automation-stop',
            'nav-search-import', 'search-import-modal', 'search-import-close-icon',
            'search-import-close', 'search-import-start', 'search-import-keyword',
            'search-import-limit', 'search-import-message',
            'nav-account-download', 'account-download-modal', 'account-download-close-icon',
            'account-download-close', 'account-download-keyword', 'account-download-search',
            'account-download-message', 'account-download-count', 'account-download-accounts',
            'account-video-toolbar', 'account-selected-name', 'account-video-results',
            'account-select-latest', 'account-select-all', 'account-clear-selection',
            'account-download-more', 'account-download-start', 'account-download-cancel',
            'nav-live-search', 'live-search-modal', 'live-search-close-icon',
            'live-search-close', 'live-search-start', 'live-search-keyword',
            'live-search-message', 'live-search-count', 'live-search-results',
            'live-search-more',
            'nav-live-library', 'live-library-modal', 'live-library-close-icon',
            'live-library-close', 'live-library-refresh', 'live-library-add',
            'live-library-keyword', 'live-library-interval', 'live-library-message',
            'live-library-count', 'live-library-targets', 'live-library-history',
        ].forEach((id) => { elements[id] = $(id); });
    }

    function getAuthHeaders() {
        try {
            const token = (localStorage.getItem('wx_channel_auth_token') || localStorage.getItem('wx_channel_token') || '').trim();
            return token ? { 'X-Local-Auth': token } : {};
        } catch (_) {
            return {};
        }
    }

    function getAuthToken() {
        try {
            return (localStorage.getItem('wx_channel_auth_token') || localStorage.getItem('wx_channel_token') || '').trim();
        } catch (_) {
            return '';
        }
    }

    async function apiFetch(path, options = {}) {
        const response = await fetch(path, {
            ...options,
            headers: { ...getAuthHeaders(), ...(options.headers || {}) },
        });
        if (!response.ok) {
            if (response.status === 401) {
                throw new Error('本地访问令牌无效，请先在原控制台完成连接配置。');
            }
            let message = `请求失败（${response.status}）`;
            try {
                const body = await response.json();
                message = body.error || body.message || message;
            } catch (_) {
                // 保留 HTTP 状态信息。
            }
            throw new Error(message);
        }
        return response;
    }

    async function checkConnection() {
        const element = elements['collector-state'];
        try {
            await apiFetch('/api/health', { signal: AbortSignal.timeout(4000) });
            element.classList.remove('error');
            element.classList.add('connected');
            element.lastElementChild.textContent = '采集器已连接';
        } catch (_) {
            element.classList.remove('connected');
            element.classList.add('error');
            element.lastElementChild.textContent = '采集器连接异常';
        }
    }

    function buildWorkspaceURL() {
        const params = new URLSearchParams({
            days: String(state.days),
            page: String(state.page),
            pageSize: String(state.pageSize),
        });
        if (state.query) params.set('query', state.query);
        if (state.author) params.set('author', state.author);
        params.set('product', state.product);
        params.set('ad', state.ad);
        params.set('sort', state.sort);
        return `/api/insights?${params.toString()}`;
    }

    async function loadWorkspace({ preserveSelection = false } = {}) {
        if (state.requestController) state.requestController.abort();
        const requestController = new AbortController();
        state.requestController = requestController;
        setLoading(true);
        try {
            const response = await apiFetch(buildWorkspaceURL(), { signal: requestController.signal });
            const payload = await response.json();
            const data = payload.data;
            if (!data || !Array.isArray(data.items)) {
                throw new Error('洞察接口返回了无法识别的数据');
            }
            state.items = Array.isArray(data.items) ? data.items : [];
            queueProductTranscriptions(state.items);
            state.totalPages = data.totalPages || 1;
            state.page = data.page || 1;
            updateMetrics(data.summary || {});
            updateAuthors(data.authors || []);
            renderRows();
            updatePagination(data.total || 0);

            const canPreserve = preserveSelection && state.items.some((item) => item.id === state.selectedId);
            if (!canPreserve) state.selectedId = state.items[0]?.id || null;
            updateSelectedRow();
            if (state.selectedId) {
                const selected = state.items.find((item) => item.id === state.selectedId);
                renderDetail(selected);
                loadCommentInsight(selected);
            } else {
                clearDetail();
            }
        } catch (error) {
            if (error.name === 'AbortError') return;
            state.items = [];
            renderRows();
            clearMetrics();
            updatePagination(0);
            clearDetail();
            showToast(error.message, 'error');
        } finally {
            if (state.requestController === requestController) {
                state.requestController = null;
                setLoading(false);
            }
        }
    }

    function setLoading(isLoading) {
        state.loading = isLoading;
        elements['loading-state'].hidden = !isLoading;
        elements['refresh-button'].classList.toggle('loading', isLoading);
        elements['refresh-button'].disabled = isLoading;
        syncEmptyState();
    }

    function syncEmptyState() {
        elements['empty-state'].hidden = state.loading || state.items.length > 0;
    }

    function updateMetrics(summary) {
        elements['metric-videos'].textContent = formatNumber(summary.totalVideos || 0);
        elements['metric-engagement'].textContent = formatCompact(summary.totalEngagement || 0);
        elements['metric-average'].textContent = formatCompact(summary.averageEngagement || 0);
        elements['metric-pending'].textContent = formatNumber(summary.pendingCount || 0);
    }

    function clearMetrics() {
        ['metric-videos', 'metric-engagement', 'metric-average', 'metric-pending'].forEach((id) => {
            elements[id].textContent = '—';
        });
    }

    function updateAuthors(authors) {
        const select = elements['author-filter'];
        const current = state.author;
        const fragment = document.createDocumentFragment();
        const allOption = document.createElement('option');
        allOption.value = '';
        allOption.textContent = '全部作者';
        fragment.appendChild(allOption);
        authors.forEach((author) => {
            const option = document.createElement('option');
            option.value = author;
            option.textContent = author;
            fragment.appendChild(option);
        });
        select.replaceChildren(fragment);
        select.value = current;
    }

    function renderRows() {
        const tbody = elements['content-rows'];
        const fragment = document.createDocumentFragment();
        state.items.forEach((item) => fragment.appendChild(createRow(item)));
        tbody.replaceChildren(fragment);
        syncEmptyState();
    }

    function createRow(item) {
        const row = document.createElement('tr');
        row.dataset.id = item.id;
        row.tabIndex = 0;
        row.setAttribute('aria-label', `查看 ${item.title || '未命名内容'} 的洞察`);
        row.addEventListener('click', () => selectItem(item.id));
        row.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                selectItem(item.id);
            }
        });

        const contentCell = document.createElement('td');
        const videoCell = document.createElement('div');
        videoCell.className = 'video-cell';
        videoCell.appendChild(createCover(item));
        const meta = document.createElement('div');
        meta.className = 'video-meta';
        const title = document.createElement('strong');
        title.textContent = item.title || '未命名内容';
        title.title = item.title || '未命名内容';
        const author = document.createElement('span');
        author.textContent = item.author || '未知作者';
        meta.append(title, author);
        if (item.isMarketingAd) {
            const badge = document.createElement('span');
            badge.className = 'disclosure-badge';
            badge.textContent = '营销广告';
            meta.appendChild(badge);
        }
        videoCell.appendChild(meta);
        contentCell.appendChild(videoCell);
        row.appendChild(contentCell);

        row.appendChild(createCell(formatDateTime(item.publishedAt || item.browseTime)));
        row.appendChild(createCell(formatCompact(item.likeCount), 'numeric'));
        row.appendChild(createCell(formatCompact(item.commentCount), 'numeric optional-column'));
        row.appendChild(createCell(formatCompact(item.favCount), 'numeric optional-column'));
        row.appendChild(createCell(formatCompact(item.forwardCount), 'numeric optional-column'));
        row.appendChild(createCell(item.score > 0 ? String(item.score) : '待分析', `numeric score-cell${item.score > 0 ? '' : ' pending'}`));
        return row;
    }

    function createCover(item) {
        const cover = document.createElement('div');
        cover.className = 'video-cover';
        if (item.coverUrl) {
            const image = document.createElement('img');
            image.src = item.coverUrl;
            image.alt = '';
            image.loading = 'lazy';
            image.referrerPolicy = 'no-referrer';
            image.addEventListener('error', () => cover.replaceChildren(createCoverFallback()));
            cover.appendChild(image);
        } else {
            cover.appendChild(createCoverFallback());
        }
        return cover;
    }

    function createCoverFallback() {
        const fallback = document.createElement('span');
        fallback.className = 'cover-fallback';
        fallback.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 8 7 4-7 4z"/><rect x="3" y="4" width="18" height="16" rx="3"/></svg>';
        return fallback;
    }

    function createCell(text, className = '') {
        const cell = document.createElement('td');
        if (className) cell.className = className;
        cell.textContent = text;
        return cell;
    }

    function selectItem(id) {
        state.selectedId = id;
        updateSelectedRow();
        const selected = state.items.find((item) => item.id === id);
        if (!selected) return;
        renderDetail(selected);
        loadCommentInsight(selected);
        if (window.matchMedia('(max-width: 900px)').matches) document.body.classList.add('detail-open');
    }

    function updateSelectedRow() {
        elements['content-rows'].querySelectorAll('tr').forEach((row) => {
            const selected = row.dataset.id === state.selectedId;
            row.classList.toggle('selected', selected);
            row.setAttribute('aria-selected', String(selected));
        });
    }

    function renderDetail(item) {
        if (!item) return clearDetail();
        elements['detail-placeholder'].hidden = true;
        elements['detail-content'].hidden = false;
        elements['detail-author'].textContent = item.author || '未知作者';
        elements['detail-name'].textContent = item.title || '未命名内容';
        const published = formatDateTime(item.publishedAt || item.browseTime);
        const captured = formatDateTime(item.browseTime);
        elements['detail-date'].textContent = `发布于 ${published} · 采集于 ${captured}`;
        elements['detail-score'].textContent = String(item.score || 0);
        elements['score-ring'].style.setProperty('--score', String(item.score || 0));
        elements['detail-likes'].textContent = formatCompact(item.likeCount);
        elements['detail-comments'].textContent = formatCompact(item.commentCount);
        elements['detail-favorites'].textContent = formatCompact(item.favCount);
        elements['detail-forwards'].textContent = formatCompact(item.forwardCount);
        elements['detail-judgement'].textContent = item.judgement || '暂无判断';
        elements['signal-list'].replaceChildren(...(item.signals || []).map((signal) => {
            const element = document.createElement('span');
            element.className = 'signal';
            element.textContent = signal;
            return element;
        }));
        elements['product-section'].hidden = !item.hasProduct;
        if (item.hasProduct) {
            elements['product-title'].textContent = item.productTitle || '已检测到商品卡，商品名称待补全';
            const meta = [item.productPrice ? `价格 ${item.productPrice}` : '', item.productId ? `商品 ID ${item.productId}` : ''].filter(Boolean);
            elements['product-meta'].textContent = meta.join(' · ');
            elements['product-meta'].hidden = meta.length === 0;
            elements['product-link'].hidden = !item.productUrl;
            elements['product-link'].href = item.productUrl || '#';
        }
        const hasVideoURL = Boolean(item.videoUrl);
        elements['media-link-state'].textContent = hasVideoURL ? '已获取视频链接' : '暂未获取视频链接';
        elements['copy-video-link'].disabled = !hasVideoURL;
        elements['play-video'].disabled = !hasVideoURL;
        elements['download-video'].disabled = !hasVideoURL;
        elements['transcribe-video'].disabled = !hasVideoURL;
        elements['media-status'].textContent = hasVideoURL ? '可以复制链接、保存视频，或调用本地模型转写。' : '当前记录没有可用视频链接，请重新打开该视频采集。';
        elements['transcript-section'].hidden = true;
        elements['transcript-text'].textContent = '';
        refreshMediaStatus(item.id);
        setCommentLoading();
    }

    function selectedItem() {
        return state.items.find((item) => item.id === state.selectedId) || null;
    }

    function queueProductTranscriptions(items) {
        (items || []).filter((item) => item?.hasProduct && item?.id && item?.videoUrl).forEach((item) => {
            if (state.autoTranscriptionRequested.has(item.id)) return;
            state.autoTranscriptionRequested.add(item.id);
            apiFetch(`/api/insights/${encodeURIComponent(item.id)}/media/transcribe`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ automatic: true }),
            }).then(() => {
                if (item.id === state.selectedId) scheduleMediaPoll(item.id);
            }).catch((error) => {
                console.warn('带货视频自动转写启动失败:', item.id, error);
            });
        });
    }

    async function copyVideoLink() {
        const item = selectedItem();
        if (!item?.videoUrl) return;
        try {
            await navigator.clipboard.writeText(item.videoUrl);
            showToast('视频链接已复制');
        } catch (_) {
            const input = document.createElement('textarea');
            input.value = item.videoUrl;
            input.style.position = 'fixed';
            input.style.opacity = '0';
            document.body.appendChild(input);
            input.select();
            document.execCommand('copy');
            input.remove();
            showToast('视频链接已复制');
        }
    }

    async function startMediaAction(action) {
        const item = selectedItem();
        if (!item?.id || !item.videoUrl) return;
        elements['download-video'].disabled = true;
        elements['transcribe-video'].disabled = true;
        elements['media-status'].textContent = action === 'download' ? '正在启动本地保存任务…' : '正在启动下载、音频提取和本地转写任务…';
        try {
            const response = await apiFetch(`/api/insights/${encodeURIComponent(item.id)}/media/${action}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: '{}',
            });
            const payload = await response.json();
            renderMediaStatus(payload.data || {}, item);
            scheduleMediaPoll(item.id);
        } catch (error) {
            elements['media-status'].textContent = error.message;
            elements['download-video'].disabled = false;
            elements['transcribe-video'].disabled = false;
            showToast(error.message, 'error');
        }
    }

    async function refreshMediaStatus(id) {
        if (!id || id !== state.selectedId) return;
        try {
            const response = await apiFetch(`/api/insights/${encodeURIComponent(id)}/media/status`);
            const payload = await response.json();
            if (id !== state.selectedId) return;
            const item = selectedItem();
            renderMediaStatus(payload.data || {}, item);
            if (payload.data?.running) scheduleMediaPoll(id);
        } catch (_) {
            // 素材状态读取失败不影响洞察主列表。
        }
    }

    function scheduleMediaPoll(id) {
        clearTimeout(state.mediaTimer);
        state.mediaTimer = setTimeout(() => refreshMediaStatus(id), 1000);
    }

    function renderMediaStatus(status, item) {
        const running = Boolean(status.running);
        const hasVideoURL = Boolean(item?.videoUrl);
        elements['download-video'].disabled = running || !hasVideoURL;
        elements['transcribe-video'].disabled = running || !hasVideoURL;
        elements['play-video'].disabled = !hasVideoURL;
        let message = status.message || (hasVideoURL ? '可以保存视频或调用本地模型转写。' : '当前记录没有可用视频链接。');
        if (running && Number.isFinite(Number(status.progress))) message += `（${Number(status.progress)}%）`;
        if (status.transcriptPath) message += ` 文字稿：${status.transcriptPath}`;
        else if (status.videoPath && !running) message += ` 视频：${status.videoPath}`;
        elements['media-status'].textContent = message;
        elements['media-status'].classList.toggle('error', status.stage === 'error');
        const transcriptText = String(status.transcriptText || '').trim();
        elements['transcript-section'].hidden = !transcriptText;
        elements['transcript-text'].textContent = transcriptText;
        if (status.stage === 'completed') showToast(status.message || '本地处理完成');
    }

    function playerSourceURL(recordId) {
        const token = getAuthToken();
        const base = `/api/insights/${encodeURIComponent(recordId)}/media/play`;
        return token ? `${base}?token=${encodeURIComponent(token)}` : base;
    }

    function playSelectedVideo() {
        const item = selectedItem();
        if (!item?.id || !item.videoUrl) return;
        state.playerRecordId = item.id;
        state.playerRefreshAttempted = false;
        elements['player-title'].textContent = item.title || '在线播放';
        elements['player-status'].textContent = '正在连接在线视频…';
        elements['player-status'].classList.remove('error');
        elements['player-modal'].hidden = false;
        elements['insight-player'].src = playerSourceURL(item.id);
        elements['insight-player'].load();
        elements['insight-player'].play().catch(() => {});
    }

    function closePlayer() {
        const player = elements['insight-player'];
        player.pause();
        player.removeAttribute('src');
        player.load();
        elements['player-modal'].hidden = true;
        state.playerRecordId = null;
        state.playerRefreshAttempted = false;
    }

    async function refreshSelectedVideoLink(item) {
        if (!item.sourceUrl && !item.nonceId) {
            throw new Error('这条旧记录没有分享链接或 nonce_id，请在微信里重新打开一次该视频。');
        }

        const response = await apiFetch(`/api/insights/${encodeURIComponent(item.id)}/media/resolve`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: '{}',
        });
        const payload = await response.json();
        Object.assign(item, payload.data || {});
        return item;
    }

    async function handlePlayerError() {
        const item = selectedItem();
        if (!item || item.id !== state.playerRecordId) return;
        if (state.playerRefreshAttempted) {
            elements['player-status'].textContent = '视频仍无法播放，请在微信里重新打开该视频后再试。';
            elements['player-status'].classList.add('error');
            return;
        }
        state.playerRefreshAttempted = true;
        elements['player-status'].textContent = '原链接可能已过期，正在通过微信自动刷新…';
        try {
            await refreshSelectedVideoLink(item);
            elements['player-status'].textContent = '链接已刷新，正在重新播放…';
            const player = elements['insight-player'];
            player.src = `${playerSourceURL(item.id)}${playerSourceURL(item.id).includes('?') ? '&' : '?'}v=${Date.now()}`;
            player.load();
            player.play().catch(() => {});
        } catch (error) {
            elements['player-status'].textContent = error.message;
            elements['player-status'].classList.add('error');
        }
    }

    async function copyTranscript() {
        const text = elements['transcript-text'].textContent || '';
        if (!text) return;
        try {
            await navigator.clipboard.writeText(text);
            showToast('文字稿已复制');
        } catch (_) {
            showToast('复制失败，请手动选择文字稿', 'error');
        }
    }

    async function loadCommentInsight(item) {
        try {
            const response = await apiFetch(`/api/insights/${encodeURIComponent(item.id)}`);
            const payload = await response.json();
            if (state.selectedId !== item.id) return;
            renderCommentInsight(payload.data || {});
        } catch (error) {
            if (state.selectedId !== item.id) return;
            renderCommentInsight({ commentsAvailable: false, keywords: [] });
            showToast(`评论洞察读取失败：${error.message}`, 'error');
        }
    }

    function setCommentLoading() {
        elements['comment-count'].textContent = '正在读取…';
        elements['keyword-list'].replaceChildren();
        elements['comment-empty'].hidden = true;
    }

    function renderCommentInsight(detail) {
        const keywords = Array.isArray(detail.keywords) ? detail.keywords : [];
        const analyzed = detail.analyzedComments || 0;
        elements['comment-count'].textContent = detail.commentsAvailable ? `已分析 ${formatNumber(analyzed)} 条` : '';
        const nodes = keywords.map((keyword) => {
            const element = document.createElement('span');
            element.className = 'keyword';
            const label = document.createElement('span');
            label.textContent = keyword.label;
            const count = document.createElement('small');
            count.textContent = String(keyword.count);
            element.append(label, count);
            return element;
        });
        elements['keyword-list'].replaceChildren(...nodes);
        elements['comment-empty'].hidden = keywords.length > 0;
        if (detail.commentsAvailable && keywords.length === 0) {
            elements['comment-empty'].querySelector('strong').textContent = '暂未识别到明确主题';
            elements['comment-empty'].querySelector('p').textContent = '评论已读取，但没有命中第一阶段的关键词词典。';
        } else {
            elements['comment-empty'].querySelector('strong').textContent = '暂无评论洞察';
            elements['comment-empty'].querySelector('p').textContent = '先在视频页面获取评论，完成后即可查看真实关键词。';
        }
    }

    function clearDetail() {
        state.selectedId = null;
        clearTimeout(state.mediaTimer);
        elements['detail-content'].hidden = true;
        elements['detail-placeholder'].hidden = false;
        document.body.classList.remove('detail-open');
    }

    function updatePagination(total) {
        elements['result-count'].textContent = `共 ${formatNumber(total)} 条`;
        elements['page-status'].textContent = `${state.page} / ${state.totalPages}`;
        elements['previous-page'].disabled = state.page <= 1;
        elements['next-page'].disabled = state.page >= state.totalPages;
    }

    function formatNumber(value) {
        return new Intl.NumberFormat('zh-CN').format(Number(value) || 0);
    }

    function formatCompact(value) {
        const number = Number(value) || 0;
        if (number >= 10000) return `${(number / 10000).toFixed(number >= 100000 ? 1 : 2).replace(/\.0$/, '')}万`;
        return formatNumber(number);
    }

    function formatDate(value) {
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return '—';
        return new Intl.DateTimeFormat('zh-CN', { month: '2-digit', day: '2-digit' }).format(date);
    }

    function formatDateTime(value) {
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return '未知时间';
        return new Intl.DateTimeFormat('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(date);
    }

    function showToast(message, type = 'success') {
        clearTimeout(state.toastTimer);
        elements.toast.textContent = message;
        elements.toast.className = `toast visible${type === 'error' ? ' error' : ''}`;
        state.toastTimer = setTimeout(() => { elements.toast.className = 'toast'; }, 3600);
    }

    async function exportData() {
        const button = elements['export-button'];
        button.disabled = true;
        try {
            const response = await apiFetch('/api/export/browse?format=csv');
            const blob = await response.blob();
            const url = URL.createObjectURL(blob);
            const anchor = document.createElement('a');
            anchor.href = url;
            anchor.download = `wx-insight-${new Date().toISOString().slice(0, 10)}.csv`;
            document.body.appendChild(anchor);
            anchor.click();
            anchor.remove();
            URL.revokeObjectURL(url);
            showToast('数据已导出');
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            button.disabled = false;
        }
    }

    function closeUpdateModal() {
        elements['update-modal'].hidden = true;
    }

    async function openUpdateModal() {
        elements['update-modal'].hidden = false;
        elements['update-close'].textContent = '稍后';
        elements['update-version'].textContent = '正在读取当前版本…';
        elements['update-message'].textContent = '正在检查新版本，请稍候。';
        elements['update-notes'].hidden = true;
        elements['update-notes'].textContent = '';
        elements['update-install'].hidden = true;
        try {
            const response = await apiFetch('/api/system/version/check');
            const payload = await response.json();
            const result = payload.data || {};
            elements['update-version'].textContent = `当前版本 v${result.currentVersion || '未知'}`;
            if (!result.hasUpdate) {
                elements['update-message'].textContent = '当前已经是最新版本，无需更新。';
                return;
            }
            elements['update-message'].textContent = `发现新版本 v${result.latestVersion}。安装后只需关闭并重新打开程序，现有数据不会被删除。`;
            if (result.releaseNotes) {
                elements['update-notes'].textContent = result.releaseNotes;
                elements['update-notes'].hidden = false;
            }
            elements['update-install'].textContent = `安装 v${result.latestVersion}`;
            elements['update-install'].hidden = false;
        } catch (error) {
            elements['update-version'].textContent = '更新检查失败';
            elements['update-message'].textContent = error.message;
        }
    }

    async function installUpdate() {
        const button = elements['update-install'];
        button.disabled = true;
        elements['update-close'].disabled = true;
        elements['update-message'].textContent = '正在下载并校验更新，请不要关闭程序。';
        try {
            const response = await apiFetch('/api/system/version/install', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WX-Insight-Update': 'confirm',
                },
                body: JSON.stringify({ confirm: true }),
            });
            const payload = await response.json();
            const result = payload.data || {};
            if (!result.installed) {
                elements['update-message'].textContent = '检查完成，当前已经是最新版本。';
                button.hidden = true;
                return;
            }
            elements['update-version'].textContent = `已安装 v${result.latestVersion}`;
            elements['update-message'].textContent = '更新文件已通过校验并安装。请关闭 wx_insight 程序，再重新打开使用新版本。';
            elements['update-notes'].hidden = true;
            button.hidden = true;
            elements['update-close'].textContent = '知道了';
            showToast('更新已安装，重启程序后生效');
        } catch (error) {
            elements['update-message'].textContent = `安装失败：${error.message}。旧版本仍可继续使用。`;
        } finally {
            button.disabled = false;
            elements['update-close'].disabled = false;
        }
    }

    const automationStateLabels = {
        idle: '未开始', running: '运行中', paused: '已暂停', stopped: '已停止',
        completed: '已完成', error: '异常停止',
    };

    function closeAutomationModal() {
        elements['automation-modal'].hidden = true;
        clearInterval(state.automationTimer);
        state.automationTimer = null;
    }

    async function openAutomationModal() {
        elements['automation-modal'].hidden = false;
        state.automationFormHydrated = false;
        await refreshAutomationStatus();
        clearInterval(state.automationTimer);
        state.automationTimer = setInterval(refreshAutomationStatus, 1000);
    }

    async function refreshAutomationStatus() {
        try {
            const response = await apiFetch('/api/automation/status');
            const payload = await response.json();
            renderAutomationStatus(payload.data || {});
        } catch (error) {
            elements['automation-message'].textContent = error.message;
            elements['automation-message'].classList.add('error');
        }
    }

    function renderAutomationStatus(status) {
        const currentState = status.state || 'idle';
        const target = Number(status.targetCount) || 20;
        const viewed = Number(status.viewedCount) || 0;
        const isActive = currentState === 'running' || currentState === 'paused';
        const isError = currentState === 'error';
        const percentage = target > 0 ? Math.min(100, Math.round((viewed / target) * 100)) : 0;

        elements['automation-state'].textContent = automationStateLabels[currentState] || currentState;
        elements['automation-state'].className = `automation-state${currentState === 'running' ? ' running' : ''}${isError ? ' error' : ''}`;
        elements['automation-progress-text'].textContent = `${viewed} / ${target}`;
        elements['automation-progress-bar'].style.width = `${percentage}%`;
        elements['automation-message'].classList.toggle('error', isError);

        const connection = elements['automation-connection'];
        connection.classList.toggle('connected', Boolean(status.agentConnected));
        elements['automation-connection-title'].textContent = status.agentConnected ? '推荐流接口页面已连接' : '未检测到推荐页';
        elements['automation-connection-message'].textContent = status.agentConnected
            ? '优先使用 finderGetRecommend 接口；页面切换仅作为初始化兜底。'
            : '请在 Windows 微信中打开视频号推荐页。';

        if (!state.automationFormHydrated) {
            elements['automation-target'].value = target;
            elements['automation-min-dwell'].value = Number(status.minDwellSeconds) || 6;
            elements['automation-max-dwell'].value = Number(status.maxDwellSeconds) || 12;
            state.automationFormHydrated = true;
        }

        ['automation-target', 'automation-min-dwell', 'automation-max-dwell'].forEach((id) => {
            elements[id].disabled = isActive || state.automationBusy;
        });
        elements['automation-start'].hidden = isActive;
        elements['automation-start'].disabled = !status.agentConnected || state.automationBusy;
        elements['automation-pause'].hidden = currentState !== 'running';
        elements['automation-resume'].hidden = currentState !== 'paused';
        elements['automation-stop'].hidden = false;
        elements['automation-stop'].disabled = state.automationControlBusy;
        elements['automation-stop'].textContent = isActive ? '停止自己刷' : '保持停止';

        elements['nav-auto-browse'].classList.toggle('automation-running', currentState === 'running');
        elements['nav-auto-browse'].classList.toggle('automation-error', isError);

        if (isError) {
            elements['automation-message'].textContent = status.lastError || '自动采集已因异常停止。';
        } else if (currentState === 'running') {
            elements['automation-message'].textContent = status.agentConnected
                ? `正在观看第 ${viewed} 条，约 ${Number(status.remainingSeconds) || 0} 秒后切换。`
                : '视频号页面连接中断；重新打开页面后任务会继续。';
        } else if (currentState === 'paused') {
            elements['automation-message'].textContent = '任务已暂停，点击“继续”后恢复计时。';
        } else if (currentState === 'completed') {
            elements['automation-message'].textContent = `已完成 ${viewed} 条视频采集。`;
        } else if (currentState === 'stopped') {
            elements['automation-message'].textContent = `已手动停止，本次进入 ${viewed} 条视频。`;
        } else {
            elements['automation-message'].textContent = status.agentConnected ? '设置采集数量后即可通过接口批量读取推荐流。' : '打开视频号推荐页后即可开始。';
        }
    }

    async function automationControl(action, body = {}) {
        const isStop = action === 'stop';
        if (state.automationControlBusy || (state.automationBusy && !isStop)) return;
        state.automationControlBusy = true;
        if (isStop && state.feedImportController) state.feedImportController.abort();
        if (isStop && state.searchImportController) state.searchImportController.abort();
        try {
            const requestOptions = {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WX-Insight-Automation': 'control',
                },
                body: JSON.stringify(body),
            };
            if (isStop) {
                const [browseResult, insightResult] = await Promise.allSettled([
                    apiFetch('/api/automation/stop', requestOptions),
                    apiFetch('/api/insights/automation/stop', { method: 'POST' }),
                ]);
                if (browseResult.status === 'rejected' || insightResult.status === 'rejected') {
                    const failure = browseResult.status === 'rejected' ? browseResult.reason : insightResult.reason;
                    throw failure instanceof Error ? failure : new Error('停止请求未完整执行');
                }
                const payload = await browseResult.value.json();
                renderAutomationStatus(payload.data || {});
            } else {
                const response = await apiFetch(`/api/automation/${action}`, requestOptions);
                const payload = await response.json();
                renderAutomationStatus(payload.data || {});
            }
            if (action === 'start') showToast('自动采集已开始');
            if (action === 'stop') showToast('推荐页自动切换与详情深检已停止；微信消息下载仍在运行');
        } catch (error) {
            elements['automation-message'].textContent = error.message;
            elements['automation-message'].classList.add('error');
            showToast(error.message, 'error');
        } finally {
            state.automationControlBusy = false;
            refreshAutomationStatus();
        }
    }

    function openSearchImportModal() {
        elements['search-import-modal'].hidden = false;
        elements['search-import-message'].textContent = '请保持 Windows 微信已登录，并打开视频号或搜一搜视频页。';
        elements['search-import-message'].classList.remove('error');
        window.setTimeout(() => elements['search-import-keyword'].focus(), 0);
    }

    function closeSearchImportModal() {
        if (state.searchImportBusy) return;
        elements['search-import-modal'].hidden = true;
    }

    async function startSearchImport() {
        if (state.searchImportBusy) return;
        const keyword = elements['search-import-keyword'].value.trim();
        const maxItems = Math.min(200, Math.max(1, Number(elements['search-import-limit'].value) || 50));
        if (!keyword) {
            elements['search-import-message'].textContent = '请先输入搜索关键词。';
            elements['search-import-message'].classList.add('error');
            elements['search-import-keyword'].focus();
            return;
        }
        state.searchImportBusy = true;
        const controller = new AbortController();
        state.searchImportController = controller;
        elements['search-import-keyword'].disabled = true;
        elements['search-import-limit'].disabled = true;
        elements['search-import-start'].disabled = true;
        elements['search-import-start'].textContent = '正在采集…';
        elements['search-import-message'].classList.remove('error');
        elements['search-import-message'].textContent = `正在读取“${keyword}”的微信视频搜索结果并自动翻页…`;
        try {
            const response = await apiFetch('/api/insights/search/import', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ keyword, maxItems }),
                signal: controller.signal,
            });
            const payload = await response.json();
            const result = payload.data || {};
            const productCount = Array.isArray(result.items) ? result.items.filter((item) => item.hasProduct).length : 0;
            const adCount = Array.isArray(result.items) ? result.items.filter((item) => item.isMarketingAd).length : 0;
            elements['search-import-message'].textContent = `完成：读取 ${result.fetched || 0} 条，新增 ${result.created || 0} 条，更新 ${result.updated || 0} 条，营销广告 ${adCount} 条，列表直接识别带货 ${productCount} 条。`;
            showToast(`“${keyword}”已采集 ${result.fetched || 0} 条`);
            state.page = 1;
            await loadWorkspace();
            await startAutomaticProductInspection(result.items, elements['search-import-message']);
        } catch (error) {
            if (error.name === 'AbortError') {
                elements['search-import-message'].textContent = '关键词采集与后续详情核验已停止。';
            } else {
                elements['search-import-message'].textContent = error.message;
                elements['search-import-message'].classList.add('error');
            }
        } finally {
            state.searchImportBusy = false;
            if (state.searchImportController === controller) state.searchImportController = null;
            elements['search-import-keyword'].disabled = false;
            elements['search-import-limit'].disabled = false;
            elements['search-import-start'].disabled = false;
            elements['search-import-start'].textContent = '开始采集';
        }
    }

    function openAccountDownloadModal() {
        elements['account-download-modal'].hidden = false;
        elements['account-download-message'].classList.remove('error');
        if (!state.accountDownloadItems.length) {
            elements['account-download-message'].textContent = '搜索账号后，选择正确账号查看其视频。';
        }
        window.setTimeout(() => elements['account-download-keyword'].focus(), 0);
    }

    function closeAccountDownloadModal() {
        if (state.accountDownloadController) state.accountDownloadController.abort();
        elements['account-download-modal'].hidden = true;
    }

    function readAccountContacts(payload) {
        const capture = payload?.data || payload || {};
        const result = capture?.data || capture || {};
        const candidates = [];
        ['infoList', 'contactList', 'userList', 'resultList', 'objectList'].forEach((key) => {
            if (Array.isArray(result[key])) candidates.push(...result[key]);
        });
        const byUsername = new Map();
        candidates.forEach((entry, index) => {
            const contact = entry?.contact || entry?.finderContact || entry?.user || entry || {};
            const username = String(contact.username || contact.finderUsername || entry?.username || '').trim();
            const nickname = String(contact.nickname || contact.nickName || entry?.nickname || '').trim();
            if (!username || !nickname) return;
            const key = username || `account-${index}`;
            if (byUsername.has(key)) return;
            byUsername.set(key, {
                username,
                nickname,
                avatar: String(contact.headUrl || contact.avatarUrl || contact.avatar || entry?.headUrl || ''),
                signature: String(contact.signature || contact.authInfo?.authProfession || contact.authInfo?.appName || ''),
            });
        });
        return Array.from(byUsername.values());
    }

    function readHistoricalAccountContacts(payload) {
        const items = payload?.data?.items || payload?.items || [];
        if (!Array.isArray(items)) return [];
        return items.map((item) => ({
            username: String(item?.username || '').trim(),
            nickname: String(item?.nickname || '').trim(),
            avatar: String(item?.avatar || ''),
            signature: String(item?.signature || '本地历史账号'),
            source: 'history',
        })).filter((item) => item.username && item.nickname);
    }

    function mergeAccountContacts(...groups) {
        const byUsername = new Map();
        groups.flat().forEach((account) => {
            if (!account?.username || byUsername.has(account.username)) return;
            byUsername.set(account.username, account);
        });
        return Array.from(byUsername.values());
    }

    function renderAccountContacts() {
        const container = elements['account-download-accounts'];
        const fragment = document.createDocumentFragment();
        state.accountDownloadAccounts.forEach((account) => {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = `account-search-result${state.accountDownloadSelectedAccount?.username === account.username ? ' active' : ''}`;
            if (account.avatar) {
                const avatar = document.createElement('img');
                avatar.src = account.avatar;
                avatar.alt = '';
                avatar.loading = 'lazy';
                avatar.referrerPolicy = 'no-referrer';
                button.appendChild(avatar);
            } else {
                const avatar = document.createElement('span');
                avatar.className = 'account-search-avatar';
                avatar.textContent = account.nickname.slice(0, 1);
                button.appendChild(avatar);
            }
            const copy = document.createElement('span');
            const name = document.createElement('strong');
            name.textContent = account.nickname;
            const meta = document.createElement('span');
            meta.textContent = account.signature || account.username;
            copy.append(name, meta);
            button.appendChild(copy);
            button.addEventListener('click', () => selectAccountForDownload(account));
            fragment.appendChild(button);
        });
        container.replaceChildren(fragment);
    }

    async function searchDownloadAccounts() {
        if (state.accountDownloadBusy) return;
        const keyword = elements['account-download-keyword'].value.trim();
        if (!keyword) {
            elements['account-download-message'].textContent = '请先输入视频号昵称。';
            elements['account-download-message'].classList.add('error');
            return;
        }
        const controller = new AbortController();
        state.accountDownloadController = controller;
        state.accountDownloadBusy = true;
        elements['account-download-search'].disabled = true;
        elements['account-download-message'].classList.remove('error');
        elements['account-download-message'].textContent = `正在搜索“${keyword}”…`;
        try {
            const params = new URLSearchParams({ keyword, type: '1', page: '1', page_size: '20' });
            let nativeAccounts = [];
            let nativeError = null;
            try {
                const response = await apiFetch(`/api/channels/contact/search?${params.toString()}`, { signal: controller.signal });
                nativeAccounts = readAccountContacts(await response.json());
            } catch (error) {
                if (error.name === 'AbortError') throw error;
                nativeError = error;
            }
            let historyAccounts = [];
            try {
                const historyParams = new URLSearchParams({ query: keyword });
                const response = await apiFetch(`/api/insights/account/search?${historyParams.toString()}`, { signal: controller.signal });
                historyAccounts = readHistoricalAccountContacts(await response.json());
            } catch (error) {
                if (error.name === 'AbortError') throw error;
                if (!nativeAccounts.length) throw nativeError || error;
            }
            state.accountDownloadAccounts = mergeAccountContacts(nativeAccounts, historyAccounts);
            state.accountDownloadSelectedAccount = null;
            state.accountDownloadItems = [];
            state.accountDownloadSelectedIds.clear();
            state.accountDownloadNextMarker = '';
            state.accountDownloadHasMore = false;
            renderAccountContacts();
            renderAccountVideos();
            elements['account-download-message'].textContent = state.accountDownloadAccounts.length
                ? `找到 ${state.accountDownloadAccounts.length} 个账号，请选择正确账号${historyAccounts.length ? '；已合并本地历史结果' : ''}。`
                : `没有找到“${keyword}”对应的账号。`;
        } catch (error) {
            elements['account-download-message'].textContent = error.name === 'AbortError' ? '账号搜索已停止。' : error.message;
            elements['account-download-message'].classList.toggle('error', error.name !== 'AbortError');
        } finally {
            state.accountDownloadBusy = false;
            if (state.accountDownloadController === controller) state.accountDownloadController = null;
            elements['account-download-search'].disabled = false;
            renderAccountVideos();
        }
    }

    async function selectAccountForDownload(account) {
        if (state.accountDownloadBusy) return;
        state.accountDownloadSelectedAccount = account;
        state.accountDownloadItems = [];
        state.accountDownloadSelectedIds.clear();
        state.accountDownloadNextMarker = '';
        state.accountDownloadHasMore = false;
        renderAccountContacts();
        renderAccountVideos();
        await loadAccountVideos();
    }

    async function loadAccountVideos({ append = false } = {}) {
        const account = state.accountDownloadSelectedAccount;
        if (!account || state.accountDownloadBusy) return;
        const controller = new AbortController();
        state.accountDownloadController = controller;
        state.accountDownloadBusy = true;
        elements['account-download-more'].disabled = true;
        elements['account-download-message'].classList.remove('error');
        elements['account-download-message'].textContent = append
            ? `正在继续读取“${account.nickname}”的视频…`
            : `正在读取“${account.nickname}”的视频列表…`;
        try {
            const response = await apiFetch('/api/insights/account/videos', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    username: account.username,
                    author: account.nickname,
                    nextMarker: append ? state.accountDownloadNextMarker : '',
                }),
                signal: controller.signal,
            });
            const payload = await response.json();
            const result = payload?.data || {};
            const existing = append ? state.accountDownloadItems : [];
            const byId = new Map(existing.map((item) => [item.id, item]));
            (Array.isArray(result.items) ? result.items : []).forEach((item) => {
                if (item?.id) byId.set(String(item.id), item);
            });
            state.accountDownloadItems = Array.from(byId.values()).sort((left, right) =>
                String(right.createTime || '').localeCompare(String(left.createTime || '')),
            );
            state.accountDownloadNextMarker = String(result.nextMarker || '');
            state.accountDownloadHasMore = Boolean(result.hasMore && state.accountDownloadNextMarker);
            elements['account-download-message'].textContent = `已加载“${account.nickname}”的 ${state.accountDownloadItems.length} 条视频；请勾选后下载。`;
            renderAccountVideos();
        } catch (error) {
            elements['account-download-message'].textContent = error.name === 'AbortError' ? '账号视频读取已停止。' : error.message;
            elements['account-download-message'].classList.toggle('error', error.name !== 'AbortError');
        } finally {
            state.accountDownloadBusy = false;
            if (state.accountDownloadController === controller) state.accountDownloadController = null;
            elements['account-download-more'].disabled = false;
            renderAccountVideos();
        }
    }

    function accountVideoMeta(item) {
        const facts = [];
        if (item.createTime) facts.push(formatDateTime(item.createTime));
        if (Number(item.durationMs) > 0) facts.push(`${Math.max(1, Math.round(Number(item.durationMs) / 1000))} 秒`);
        if (Number(item.likeCount) > 0) facts.push(`赞 ${formatCompact(item.likeCount)}`);
        if (!item.canDownload) facts.push('缺少下载凭证');
        return facts.join(' · ');
    }

    function renderAccountVideos() {
        const container = elements['account-video-results'];
        const fragment = document.createDocumentFragment();
        elements['account-video-toolbar'].hidden = !state.accountDownloadSelectedAccount;
        elements['account-selected-name'].textContent = state.accountDownloadSelectedAccount
            ? `${state.accountDownloadSelectedAccount.nickname} · 已加载 ${state.accountDownloadItems.length} 条`
            : '';
        if (!state.accountDownloadItems.length) {
            const empty = document.createElement('div');
            empty.className = 'live-search-empty';
            empty.textContent = state.accountDownloadBusy ? '正在读取账号视频…' : (state.accountDownloadSelectedAccount ? '该账号暂未返回可见视频' : '先选择一个账号');
            fragment.appendChild(empty);
        }
        state.accountDownloadItems.forEach((item) => {
            const selected = state.accountDownloadSelectedIds.has(String(item.id));
            const row = document.createElement('label');
            row.className = `account-video-item${selected ? ' selected' : ''}${item.canDownload ? '' : ' unavailable'}`;
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.checked = selected;
            checkbox.disabled = !item.canDownload;
            checkbox.addEventListener('change', () => {
                if (checkbox.checked) state.accountDownloadSelectedIds.add(String(item.id));
                else state.accountDownloadSelectedIds.delete(String(item.id));
                renderAccountVideos();
            });
            const cover = document.createElement('img');
            cover.className = 'account-video-cover';
            cover.src = item.coverUrl || '';
            cover.alt = '';
            cover.loading = 'lazy';
            cover.referrerPolicy = 'no-referrer';
            const copy = document.createElement('div');
            copy.className = 'account-video-copy';
            const title = document.createElement('strong');
            title.textContent = item.title || item.id;
            const meta = document.createElement('p');
            meta.textContent = accountVideoMeta(item);
            copy.append(title, meta);
            row.append(checkbox, cover, copy);
            fragment.appendChild(row);
        });
        container.replaceChildren(fragment);
        const selectedCount = state.accountDownloadSelectedIds.size;
        elements['account-download-count'].textContent = state.accountDownloadItems.length
            ? `${selectedCount} / ${state.accountDownloadItems.length} 已选择`
            : '';
        elements['account-download-start'].disabled = selectedCount === 0 || state.accountDownloadBusy;
        elements['account-download-start'].textContent = `下载所选（${selectedCount}）`;
        elements['account-download-more'].hidden = !state.accountDownloadHasMore;
    }

    function selectLatestAccountVideos() {
        state.accountDownloadSelectedIds.clear();
        state.accountDownloadItems.filter((item) => item.canDownload).slice(0, 20).forEach((item) => {
            state.accountDownloadSelectedIds.add(String(item.id));
        });
        renderAccountVideos();
    }

    function selectAllAccountVideos() {
        state.accountDownloadItems.filter((item) => item.canDownload).forEach((item) => {
            state.accountDownloadSelectedIds.add(String(item.id));
        });
        renderAccountVideos();
    }

    function clearAccountVideoSelection() {
        state.accountDownloadSelectedIds.clear();
        renderAccountVideos();
    }

    async function startSelectedAccountDownloads() {
        const selected = state.accountDownloadItems.filter((item) => state.accountDownloadSelectedIds.has(String(item.id)) && item.canDownload);
        if (!selected.length) return;
        elements['account-download-start'].disabled = true;
        elements['account-download-message'].classList.remove('error');
        elements['account-download-message'].textContent = `正在提交 ${selected.length} 条下载任务…`;
        const videos = selected.map((item) => ({
            id: String(item.id),
            title: item.title || String(item.id),
            authorName: item.author || state.accountDownloadSelectedAccount?.nickname || '未知作者',
            url: item.videoUrl,
            key: item.decryptKey,
            cover: item.coverUrl || '',
            headers: { Referer: 'https://channels.weixin.qq.com/', Origin: 'https://channels.weixin.qq.com' },
            sourceUrl: 'https://channels.weixin.qq.com/',
            durationMs: Number(item.durationMs) || 0,
            size: Number(item.size) || 0,
            resolution: item.resolution || '',
            fileFormat: item.fileFormat || '',
            createTime: item.createTime || '',
            likeCount: String(item.likeCount || 0),
            commentCount: String(item.commentCount || 0),
            favCount: String(item.favCount || 0),
            forwardCount: String(item.forwardCount || 0),
        }));
        try {
            const response = await apiFetch('/__wx_channels_api/batch_start', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ videos, forceRedownload: false, pageSource: 'account_manual' }),
            });
            const payload = await response.json();
            const data = payload?.data || payload || {};
            if (Number(payload?.code || 0) !== 0 || data.success === false) {
                throw new Error(payload?.message || data.error || '启动下载失败');
            }
            elements['account-download-message'].textContent = `已开始下载 ${selected.length} 条视频；可关闭窗口，任务会在后台继续。`;
            elements['account-download-cancel'].hidden = false;
            clearInterval(state.accountDownloadBatchTimer);
            state.accountDownloadBatchTimer = window.setInterval(pollAccountDownloadProgress, 1500);
            await pollAccountDownloadProgress();
        } catch (error) {
            elements['account-download-message'].textContent = error.message;
            elements['account-download-message'].classList.add('error');
            renderAccountVideos();
        }
    }

    async function pollAccountDownloadProgress() {
        try {
            const response = await apiFetch('/__wx_channels_api/batch_progress', { method: 'POST' });
            const payload = await response.json();
            const data = payload?.data || payload || {};
            const total = Number(data.total) || 0;
            const done = Number(data.done) || 0;
            const failed = Number(data.failed) || 0;
            const running = Number(data.running) || 0;
            if (total > 0) {
                elements['account-download-message'].textContent = `下载进度：完成 ${done}/${total}，失败 ${failed}，进行中 ${running}。`;
            }
            if (total > 0 && done + failed >= total && running === 0) {
                clearInterval(state.accountDownloadBatchTimer);
                state.accountDownloadBatchTimer = null;
                elements['account-download-cancel'].hidden = true;
                elements['account-download-message'].textContent = `下载结束：成功 ${done} 条，失败 ${failed} 条。`;
                showToast(`指定账号下载完成：成功 ${done} 条`);
            }
        } catch (error) {
            clearInterval(state.accountDownloadBatchTimer);
            state.accountDownloadBatchTimer = null;
            elements['account-download-message'].textContent = `下载进度读取失败：${error.message}`;
            elements['account-download-message'].classList.add('error');
        }
    }

    async function cancelAccountDownloads() {
        try {
            await apiFetch('/__wx_channels_api/batch_cancel', { method: 'POST' });
            clearInterval(state.accountDownloadBatchTimer);
            state.accountDownloadBatchTimer = null;
            elements['account-download-cancel'].hidden = true;
            elements['account-download-message'].textContent = '指定账号下载已取消。';
            showToast('下载已取消');
        } catch (error) {
            elements['account-download-message'].textContent = error.message;
            elements['account-download-message'].classList.add('error');
        }
    }

    function openLiveSearchModal() {
        elements['live-search-modal'].hidden = false;
        elements['live-search-message'].textContent = '输入关键词即可搜索，不需要先在微信里手动搜索。';
        elements['live-search-message'].classList.remove('error');
        window.setTimeout(() => elements['live-search-keyword'].focus(), 0);
    }

    function closeLiveSearchModal() {
        if (state.liveSearchBusy) return;
        elements['live-search-modal'].hidden = true;
    }

    async function openLiveLibraryModal() {
        elements['live-library-modal'].hidden = false;
        elements['live-library-message'].textContent = '正在读取直播监控关键词…';
        elements['live-library-message'].classList.remove('error');
        await loadLiveLibraryTargets({ refreshHistory: true });
        clearInterval(state.liveLibraryTimer);
        state.liveLibraryTimer = window.setInterval(() => loadLiveLibraryTargets({
            refreshHistory: state.liveLibraryTargets.some((item) => ['queued', 'running'].includes(item.lastStatus)),
        }), 3000);
        window.setTimeout(() => elements['live-library-keyword'].focus(), 0);
    }

    function closeLiveLibraryModal() {
        elements['live-library-modal'].hidden = true;
        clearInterval(state.liveLibraryTimer);
        state.liveLibraryTimer = null;
    }

    function liveMonitorStatusLabel(status) {
        return {
            pending: '等待首轮', queued: '已排队', running: '采集中',
            success: '成功', failed: '失败', waiting_connection: '等待微信连接',
        }[status] || status || '未知';
    }

    async function loadLiveLibraryTargets({ refreshHistory = false } = {}) {
        try {
            const response = await apiFetch('/api/insights/live/monitors');
            const payload = await response.json();
            state.liveLibraryTargets = Array.isArray(payload?.data?.items) ? payload.data.items : [];
            if (state.liveLibrarySelectedTarget && !state.liveLibraryTargets.some((item) => item.id === state.liveLibrarySelectedTarget)) {
                state.liveLibrarySelectedTarget = null;
            }
            renderLiveLibraryTargets();
            const running = state.liveLibraryTargets.filter((item) => ['queued', 'running'].includes(item.lastStatus)).length;
            elements['live-library-count'].textContent = `${state.liveLibraryTargets.length} 个关键词${running ? ` · ${running} 个采集中` : ''}`;
            elements['live-library-message'].textContent = state.liveLibraryTargets.length
                ? '后台自动搜索已暂停；点击关键词旁的“立即采集”才会操作微信页面。'
                : '还没有监控关键词，添加后会立即采集第一轮。';
            elements['live-library-message'].classList.remove('error');
            if (refreshHistory && state.liveLibrarySelectedTarget) {
                await loadLiveLibraryHistory(state.liveLibrarySelectedTarget);
            }
        } catch (error) {
            elements['live-library-message'].textContent = error.message;
            elements['live-library-message'].classList.add('error');
        }
    }

    function renderLiveLibraryTargets() {
        const container = elements['live-library-targets'];
        const fragment = document.createDocumentFragment();
        if (!state.liveLibraryTargets.length) {
            const empty = document.createElement('div');
            empty.className = 'live-search-empty';
            empty.textContent = '暂无直播监控关键词';
            fragment.appendChild(empty);
        }
        state.liveLibraryTargets.forEach((target) => {
            const card = document.createElement('article');
            card.className = `live-library-target${state.liveLibrarySelectedTarget === target.id ? ' selected' : ''}`;
            const head = document.createElement('div');
            head.className = 'live-library-target-head';
            const keyword = document.createElement('strong');
            keyword.textContent = target.keyword;
            const status = document.createElement('span');
            status.className = `live-library-status ${target.lastStatus || ''}`;
            status.textContent = target.enabled ? liveMonitorStatusLabel(target.lastStatus) : '已暂停';
            head.append(keyword, status);
            const summary = document.createElement('p');
            const schedule = '后台自动采集已暂停';
            summary.textContent = `记录间隔设置 ${target.intervalMinutes} 分钟 · 上次 ${target.lastRunAt ? formatDateTime(target.lastRunAt) : '尚未运行'} · ${schedule}`;
            const counts = document.createElement('p');
            counts.textContent = `上次结果 ${Number(target.lastResultCount) || 0} 位主播 · ${Number(target.lastLiveCount) || 0} 位直播中${target.lastError ? ` · ${target.lastError}` : ''}`;
            const actions = document.createElement('div');
            actions.className = 'live-library-target-actions';
            const history = document.createElement('button');
            history.type = 'button';
            history.textContent = '查看记录';
            history.addEventListener('click', () => {
                state.liveLibrarySelectedTarget = target.id;
                renderLiveLibraryTargets();
                loadLiveLibraryHistory(target.id);
            });
            const run = document.createElement('button');
            run.type = 'button';
            run.textContent = '立即采集';
            run.disabled = !target.enabled || ['queued', 'running'].includes(target.lastStatus);
            run.addEventListener('click', () => triggerLiveLibraryTarget(target.id));
            const toggle = document.createElement('button');
            toggle.type = 'button';
            toggle.textContent = target.enabled ? '停用' : '启用';
            toggle.addEventListener('click', () => updateLiveLibraryTarget(target, { enabled: !target.enabled }));
            const remove = document.createElement('button');
            remove.type = 'button';
            remove.className = 'danger-button';
            remove.textContent = '删除';
            remove.addEventListener('click', () => deleteLiveLibraryTarget(target));
            actions.append(history, run, toggle, remove);
            card.append(head, summary, counts, actions);
            fragment.appendChild(card);
        });
        container.replaceChildren(fragment);
    }

    async function addLiveLibraryTarget() {
        const keyword = elements['live-library-keyword'].value.trim();
        const intervalMinutes = Math.min(1440, Math.max(15, Number(elements['live-library-interval'].value) || 60));
        if (!keyword) {
            elements['live-library-message'].textContent = '请先输入要监控的主播或品牌关键词。';
            elements['live-library-message'].classList.add('error');
            return;
        }
        elements['live-library-add'].disabled = true;
        try {
            const response = await apiFetch('/api/insights/live/monitors', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ keyword, intervalMinutes }),
            });
            const payload = await response.json();
            const target = payload?.data;
            state.liveLibrarySelectedTarget = target?.id || null;
            elements['live-library-keyword'].value = '';
            await apiFetch(`/api/insights/live/monitors/${target.id}/run`, { method: 'POST' });
            showToast(`已添加“${keyword}”，正在采集第一轮`);
            await loadLiveLibraryTargets({ refreshHistory: true });
        } catch (error) {
            elements['live-library-message'].textContent = error.message;
            elements['live-library-message'].classList.add('error');
        } finally {
            elements['live-library-add'].disabled = false;
        }
    }

    async function triggerLiveLibraryTarget(targetId) {
        try {
            await apiFetch(`/api/insights/live/monitors/${targetId}/run`, { method: 'POST' });
            showToast('已开始采集该关键词');
            await loadLiveLibraryTargets({ refreshHistory: true });
        } catch (error) {
            showToast(error.message, 'error');
        }
    }

    async function updateLiveLibraryTarget(target, changes) {
        try {
            await apiFetch(`/api/insights/live/monitors/${target.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    keyword: target.keyword,
                    enabled: changes.enabled ?? target.enabled,
                    intervalMinutes: changes.intervalMinutes || target.intervalMinutes,
                }),
            });
            await loadLiveLibraryTargets({ refreshHistory: true });
        } catch (error) {
            showToast(error.message, 'error');
        }
    }

    async function deleteLiveLibraryTarget(target) {
        if (!window.confirm(`删除“${target.keyword}”及其全部历史采集记录？`)) return;
        try {
            await apiFetch(`/api/insights/live/monitors/${target.id}`, { method: 'DELETE' });
            if (state.liveLibrarySelectedTarget === target.id) {
                state.liveLibrarySelectedTarget = null;
                elements['live-library-history'].replaceChildren(Object.assign(document.createElement('div'), {
                    className: 'live-search-empty',
                    textContent: '选择一个关键词查看历史采集记录',
                }));
            }
            await loadLiveLibraryTargets();
        } catch (error) {
            showToast(error.message, 'error');
        }
    }

    async function loadLiveLibraryHistory(targetId, selectedRunId = null) {
        const target = state.liveLibraryTargets.find((item) => item.id === targetId);
        if (!target) return;
        try {
            const response = await apiFetch(`/api/insights/live/monitors/${targetId}/runs?limit=50`);
            const payload = await response.json();
            const runs = Array.isArray(payload?.data?.items) ? payload.data.items : [];
            const runId = selectedRunId || runs[0]?.id;
            await renderLiveLibraryHistory(target, runs, runId);
        } catch (error) {
            elements['live-library-history'].replaceChildren(Object.assign(document.createElement('div'), {
                className: 'live-search-empty',
                textContent: error.message,
            }));
        }
    }

    async function renderLiveLibraryHistory(target, runs, selectedRunId) {
        const container = elements['live-library-history'];
        const header = document.createElement('div');
        header.className = 'live-library-history-header';
        const copy = document.createElement('div');
        const title = document.createElement('h3');
        title.textContent = target.keyword;
        const description = document.createElement('p');
        description.textContent = '每次采集都是独立批次，可回看观看人数和商品变化';
        copy.append(title, description);
        const label = document.createElement('label');
        const labelText = document.createElement('span');
        labelText.textContent = '采集批次';
        const select = document.createElement('select');
        select.className = 'live-library-run-select';
        if (!runs.length) {
            const option = document.createElement('option');
            option.textContent = '暂无采集批次';
            select.appendChild(option);
            select.disabled = true;
        } else {
            runs.forEach((run) => {
                const option = document.createElement('option');
                option.value = String(run.id);
                option.selected = Number(run.id) === Number(selectedRunId);
                option.textContent = `${formatDateTime(run.startedAt)} · ${liveMonitorStatusLabel(run.status)} · ${run.liveCount}/${run.totalCount} 直播`;
                select.appendChild(option);
            });
            select.addEventListener('change', () => loadLiveLibraryHistory(target.id, Number(select.value)));
        }
        label.append(labelText, select);
        header.append(copy, label);
        const records = document.createElement('div');
        records.className = 'live-library-records';
        container.replaceChildren(header, records);
        if (!selectedRunId) {
            records.appendChild(Object.assign(document.createElement('div'), {
                className: 'live-search-empty',
                textContent: '第一轮采集尚未完成',
            }));
            return;
        }
        const response = await apiFetch(`/api/insights/live/runs/${selectedRunId}/records?limit=500`);
        const payload = await response.json();
        const items = Array.isArray(payload?.data?.items) ? payload.data.items : [];
        if (!items.length) {
            records.appendChild(Object.assign(document.createElement('div'), {
                className: 'live-search-empty',
                textContent: '该批次没有主播明细，可能仍在采集中或本次搜索失败',
            }));
            return;
        }
        items.forEach((record) => {
            const row = document.createElement('article');
            row.className = `live-library-record${record.isLive ? ' is-live' : ''}`;
            if (record.avatarUrl) {
                const avatar = document.createElement('img');
                avatar.src = record.avatarUrl;
                avatar.alt = '';
                avatar.loading = 'lazy';
                avatar.referrerPolicy = 'no-referrer';
                row.appendChild(avatar);
            } else {
                const avatar = document.createElement('span');
                avatar.className = 'live-library-record-avatar';
                avatar.textContent = String(record.nickname || '?').slice(0, 1);
                row.appendChild(avatar);
            }
            const details = document.createElement('div');
            const name = document.createElement('strong');
            name.textContent = `${record.nickname || '未知主播'} · ${record.isLive ? '直播中' : '未开播'}`;
            const metrics = document.createElement('p');
            metrics.textContent = [
                record.isLive ? `观看 ${record.viewerWording || record.viewerCount || 0}` : '',
                record.likeCount ? `点赞 ${formatCompact(record.likeCount)}` : '',
                record.liveId ? `Live ID ${record.liveId}` : '',
                `抓取 ${formatDateTime(record.capturedAt)}`,
            ].filter(Boolean).join(' · ');
            details.append(name, metrics);
            const products = Array.isArray(record.products) ? record.products : [];
            if (products.length) {
                const productLine = document.createElement('p');
                productLine.className = 'live-library-record-products';
                productLine.textContent = `带货 ${products.length} 件：${products.map((item) => item.title || item.productName || item.productId || '未命名商品').join('、')}`;
                details.appendChild(productLine);
            }
            if (record.signature || record.profession) {
                const profile = document.createElement('p');
                profile.textContent = record.profession || record.signature;
                details.appendChild(profile);
            }
            row.appendChild(details);
            records.appendChild(row);
        });
    }

    function readLiveSearchResult(payload) {
        const capture = payload?.data || payload || {};
        const result = capture?.data || capture || {};
        return {
            infoList: Array.isArray(result.infoList) ? result.infoList : [],
            objectList: Array.isArray(result.objectList) ? result.objectList : [],
            nextMarker: String(result.lastBuff || result.lastBuffer || ''),
            hasMore: Number(result.continueFlag) === 1,
            capturedAt: Number(capture.capturedAt) || Date.now(),
        };
    }

    async function refreshLiveSearchMetadata(result) {
        const objectIds = Array.from(new Set(
            result.objectList
                .map((item) => String(item?.id || item?.objectId || '').trim())
                .filter(Boolean),
        ));
        if (!objectIds.length) return result;

        const response = await apiFetch('/api/channels/live/batch-info', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ objectIds, latitude: 0, longitude: 0 }),
        });
        const payload = await response.json();
        const apiResult = payload?.data?.data || payload?.data || payload || {};
        if (Number(apiResult.errCode || 0) !== 0) {
            throw new Error(apiResult.errMsg || '直播观看人数刷新失败');
        }
        const refreshedObjects = Array.isArray(apiResult.object)
            ? apiResult.object
            : Array.isArray(apiResult.objectList) ? apiResult.objectList : [];
        const refreshedById = new Map(refreshedObjects.map((item) => [
            String(item?.id || item?.objectId || ''),
            item,
        ]));
        return {
            ...result,
            capturedAt: Date.now(),
            objectList: result.objectList.map((item) => {
                const refreshed = refreshedById.get(String(item?.id || item?.objectId || ''));
                if (!refreshed) return item;
                return {
                    ...item,
                    ...refreshed,
                    contact: { ...(item.contact || {}), ...(refreshed.contact || {}) },
                    liveInfo: { ...(item.liveInfo || {}), ...(refreshed.liveInfo || {}) },
                    cookie: refreshed.cookie || item.cookie || '',
                };
            }),
        };
    }

    async function readStoredLiveSearchResult(keyword) {
        const params = new URLSearchParams({ keyword, limit: '50' });
        const response = await apiFetch(`/api/insights/live/snapshots?${params.toString()}`);
        const payload = await response.json();
        const snapshots = payload?.data?.items || [];
        const latestByObject = new Map();
        snapshots.forEach((snapshot) => {
            const objectId = String(snapshot?.objectId || '').trim();
            if (!objectId || latestByObject.has(objectId)) return;
            latestByObject.set(objectId, snapshot);
        });
        const objectList = Array.from(latestByObject.values()).map((snapshot) => ({
            id: String(snapshot.objectId || ''),
            objectId: String(snapshot.objectId || ''),
            contact: {
                username: String(snapshot.anchorUsername || ''),
                nickname: String(snapshot.nickname || ''),
                liveStatus: 1,
            },
            liveInfo: {
                liveId: String(snapshot.liveId || ''),
                liveStatus: 1,
                participantCount: Number(snapshot.viewerCount) || 0,
                liveSquareParticipantWording: String(snapshot.viewerWording || snapshot.viewerCount || ''),
            },
        }));
        if (!objectList.length) {
            throw new Error(`没有“${keyword}”的历史直播结果，需先成功搜索一次该关键词。`);
        }
        return {
            infoList: objectList.map((item) => ({ contact: item.contact })),
            objectList,
            nextMarker: '',
            hasMore: false,
            capturedAt: Date.now(),
        };
    }

    function compactCount(value) {
        if (typeof value === 'number' && Number.isFinite(value)) return Math.max(0, Math.round(value));
        const text = String(value ?? '').replace(/,/g, '').trim();
        if (!text) return 0;
        const matched = text.match(/([\d.]+)\s*([万亿]?)/);
        if (!matched) return 0;
        const amount = Number(matched[1]);
        if (!Number.isFinite(amount)) return 0;
        const multiplier = matched[2] === '亿' ? 100000000 : matched[2] === '万' ? 10000 : 1;
        return Math.max(0, Math.round(amount * multiplier));
    }

    function mergeLiveSearchItems(result, append) {
        const previous = append ? state.liveSearchItems : [];
        const byKey = new Map(previous.map((item) => [item.key, item]));
        const liveObjects = new Map();
        result.objectList.forEach((object) => {
            const contact = object.contact || {};
            const key = contact.username || object.username || contact.nickname || object.nickname;
            if (key) liveObjects.set(key, object);
        });
        result.infoList.forEach((entry, index) => {
            const contact = entry.contact || {};
            const key = contact.username || contact.nickname || `result-${index}`;
            const liveObject = liveObjects.get(contact.username) || liveObjects.get(contact.nickname) || null;
            const liveInfo = liveObject?.liveInfo || {};
            const previousItem = byKey.get(key) || {};
            byKey.set(key, {
                ...previousItem,
                key,
                nickname: contact.nickname || liveObject?.nickname || '未知主播',
                username: contact.username || liveObject?.username || '',
                avatar: contact.headUrl || '',
                signature: contact.signature || '',
                profession: contact.authInfo?.authProfession || contact.authInfo?.appName || '',
                isLive: Number(contact.liveStatus) === 1 || Number(liveInfo.liveStatus) === 1,
                liveId: String(liveInfo.liveId || ''),
                objectId: String(liveObject?.id || liveObject?.objectId || ''),
                liveCookies: String(liveObject?.cookie || ''),
                viewers: liveInfo.liveSquareParticipantWording || liveInfo.participantCount || '',
                viewerCount: compactCount(liveInfo.liveSquareParticipantWording || liveInfo.participantCount),
                likes: Number(liveInfo.likeCnt) || 0,
                streamUrl: liveInfo.streamUrl || liveInfo.liveSdkInfo?.liveCdnUrl || '',
                urlValidDuration: Number(liveObject?.urlValidDuration || liveInfo.urlValidDuration) || 0,
                capturedAt: result.capturedAt,
            });
        });
        liveObjects.forEach((liveObject, key) => {
            if (byKey.has(key)) return;
            const contact = liveObject.contact || {};
            const liveInfo = liveObject.liveInfo || {};
            const previousItem = byKey.get(key) || {};
            byKey.set(key, {
                ...previousItem,
                key,
                nickname: contact.nickname || liveObject.nickname || '未知主播',
                username: contact.username || liveObject.username || '',
                avatar: contact.headUrl || '',
                signature: contact.signature || '',
                profession: contact.authInfo?.authProfession || contact.authInfo?.appName || '',
                isLive: Number(liveInfo.liveStatus) === 1,
                liveId: String(liveInfo.liveId || ''),
                objectId: String(liveObject.id || liveObject.objectId || ''),
                liveCookies: String(liveObject.cookie || ''),
                viewers: liveInfo.liveSquareParticipantWording || liveInfo.participantCount || '',
                viewerCount: compactCount(liveInfo.liveSquareParticipantWording || liveInfo.participantCount),
                likes: Number(liveInfo.likeCnt) || 0,
                streamUrl: liveInfo.streamUrl || liveInfo.liveSdkInfo?.liveCdnUrl || '',
                urlValidDuration: Number(liveObject.urlValidDuration || liveInfo.urlValidDuration) || 0,
                capturedAt: result.capturedAt,
            });
        });
        state.liveSearchItems = Array.from(byKey.values()).sort((left, right) => {
            if (left.isLive !== right.isLive) return left.isLive ? -1 : 1;
            return left.nickname.localeCompare(right.nickname, 'zh-CN');
        });
    }

    function liveProductPrice(value) {
        const amount = Number(value);
        if (!Number.isFinite(amount) || amount <= 0) return '';
        return `¥${(amount / 100).toFixed(2).replace(/\.00$/, '')}`;
    }

    function normalizeLiveProducts(payload) {
        const apiResult = payload?.data || payload || {};
        const shelf = apiResult?.data || {};
        const itemList = Array.isArray(shelf.itemList) ? shelf.itemList : [];
        return itemList.flatMap((item) => {
            if (Number(item?.itemType) !== 0 || !item?.extInfo || typeof item.extInfo !== 'object') return [];
            const product = item.extInfo;
            const sku = product.skuAttrInfoList?.skuAttrInfos?.find((entry) => entry?.halfPage?.appid && entry?.halfPage?.path);
            return [{
                title: String(product.title || '').trim() || '未命名商品',
                productId: String(product.productId || ''),
                outProductId: String(product.outProductId || ''),
                price: liveProductPrice(product.sellingPrice),
                marketPrice: liveProductPrice(product.marketPrice),
                priceWording: String(product.sellingPriceWording || ''),
                platformName: String(product.platformName || ''),
                image: Array.isArray(product.imgUrls) ? String(product.imgUrls[0] || '') : '',
                appid: String(sku?.halfPage?.appid || ''),
                path: String(sku?.halfPage?.path || ''),
            }];
        });
    }

    async function loadLiveShopShelf(item) {
        if (!item?.isLive || !item.liveId || !item.objectId || !item.username) return;
        if (state.liveSearchProductLoads.has(item.key)) return;
        state.liveSearchProductLoads.add(item.key);
        item.productStatus = 'loading';
        item.productError = '';
        renderLiveSearchResults();
        try {
            const response = await apiFetch('/api/channels/live/shop-shelf', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    liveId: item.liveId,
                    objectId: item.objectId,
                    anchorFinderUsername: item.username,
                    liveCookies: item.liveCookies || '',
                    scene: 2,
                    pullScene: 0,
                }),
            });
            const payload = await response.json();
            const apiResult = payload?.data || payload || {};
            if (Number(apiResult.errCode || 0) !== 0) throw new Error(apiResult.errMsg || '商品接口返回失败');
            item.products = normalizeLiveProducts(payload);
            item.productStatus = item.products.length ? 'ready' : 'empty';
        } catch (error) {
            item.products = [];
            item.productStatus = 'error';
            item.productError = error.message || '商品读取失败';
        } finally {
            state.liveSearchProductLoads.delete(item.key);
            renderLiveSearchResults();
        }
    }

    async function hydrateLiveShopShelves(items) {
        const queue = items.filter((item) => item.isLive && item.liveId && item.objectId && item.username && !item.productStatus);
        let cursor = 0;
        async function worker() {
            while (cursor < queue.length) {
                const item = queue[cursor];
                cursor += 1;
                await loadLiveShopShelf(item);
            }
        }
        await Promise.all(Array.from({ length: Math.min(3, queue.length) }, () => worker()));
    }

    async function persistLiveSnapshots(items) {
        const snapshots = items.filter((item) => item.isLive && item.liveId).map((item) => {
            const captured = new Date(Number(item.capturedAt) || Date.now());
            return {
                keyword: state.liveSearchKeyword,
                anchorUsername: item.username || '',
                nickname: item.nickname || '',
                liveId: item.liveId,
                objectId: item.objectId || '',
                viewerCount: Number(item.viewerCount) || compactCount(item.viewers),
                viewerWording: String(item.viewers || ''),
                productCount: Array.isArray(item.products) ? item.products.length : 0,
                products: Array.isArray(item.products) ? item.products : [],
                capturedAt: Number.isNaN(captured.getTime()) ? new Date().toISOString() : captured.toISOString(),
            };
        });
        if (!snapshots.length) return 0;
        const response = await apiFetch('/api/insights/live/snapshots', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ items: snapshots }),
        });
        const payload = await response.json();
        return Number(payload?.data?.saved) || 0;
    }

    async function startAutomaticProductInspection(items, messageElement) {
        const ids = Array.isArray(items)
            ? items.filter((item) => item?.id && item.productStatus === 'unknown').map((item) => item.id)
            : [];
        if (!ids.length) return;
        state.productInspectionMessageElement = messageElement || null;
        const response = await apiFetch('/api/insights/product/inspect-batch', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids }),
        });
        const payload = await response.json();
        const result = payload?.data || {};
        const job = result.job || {};
        if (messageElement) {
            messageElement.textContent += ` 已自动提交 ${Number(job.requested) || ids.length} 条详情挂车核验。`;
        }
        clearInterval(state.productInspectionTimer);
        state.productInspectionTimer = window.setInterval(pollProductInspection, 1500);
        await pollProductInspection();
    }

    async function pollProductInspection() {
        try {
            const response = await apiFetch('/api/insights/product/inspect-batch');
            const payload = await response.json();
            const job = payload?.data || {};
            const messageElement = state.productInspectionMessageElement;
            if (messageElement && job.status === 'running') {
                messageElement.textContent = `正在逐条核验挂车：${Number(job.processed) || 0}/${Number(job.requested) || 0}，已确认带货 ${Number(job.withProduct) || 0}，确认非带货 ${Number(job.withoutProduct) || 0}。`;
            }
            if (messageElement && job.status === 'stopping') {
                messageElement.textContent = '正在停止详情挂车核验…';
            }
            if (job.status === 'stopped') {
                clearInterval(state.productInspectionTimer);
                state.productInspectionTimer = null;
                if (messageElement) messageElement.textContent = '详情挂车核验已停止。';
                return;
            }
            if (job.status === 'completed') {
                clearInterval(state.productInspectionTimer);
                state.productInspectionTimer = null;
                if (messageElement) {
                    messageElement.textContent = `挂车核验完成：${Number(job.processed) || 0} 条，确认带货 ${Number(job.withProduct) || 0}，确认非带货 ${Number(job.withoutProduct) || 0}，失败 ${Number(job.failed) || 0}，待重试 ${Number(job.deferred) || 0}。`;
                }
                showToast(`挂车核验完成：带货 ${Number(job.withProduct) || 0} 条`);
                await loadWorkspace({ preserveSelection: true });
            }
        } catch (error) {
            clearInterval(state.productInspectionTimer);
            state.productInspectionTimer = null;
            if (state.productInspectionMessageElement) {
                state.productInspectionMessageElement.textContent = `挂车核验状态读取失败：${error.message}`;
                state.productInspectionMessageElement.classList.add('error');
            }
        }
    }

    function appendLiveProducts(row, item) {
        if (!item.isLive || (!item.productStatus && !item.products?.length)) return;
        const section = document.createElement('div');
        section.className = 'live-search-products';
        if (item.productStatus === 'loading') {
            section.textContent = '正在读取直播货架…';
        } else if (item.productStatus === 'empty') {
            section.textContent = '当前货架未返回商品';
        } else if (item.productStatus === 'error') {
            const message = document.createElement('span');
            message.textContent = item.productError || '商品读取失败';
            const retry = document.createElement('button');
            retry.type = 'button';
            retry.textContent = '重试读取';
            retry.addEventListener('click', () => {
                item.productStatus = '';
                loadLiveShopShelf(item);
            });
            section.append(message, retry);
        } else {
            const heading = document.createElement('div');
            heading.className = 'live-search-products-heading';
            heading.textContent = `直播货架 · ${item.products.length} 件商品`;
            section.appendChild(heading);
            item.products.forEach((product) => {
                const card = document.createElement('div');
                card.className = 'live-search-product';
                if (product.image) {
                    const image = document.createElement('img');
                    image.src = product.image;
                    image.alt = '';
                    image.loading = 'lazy';
                    image.referrerPolicy = 'no-referrer';
                    card.appendChild(image);
                }
                const details = document.createElement('div');
                const title = document.createElement('strong');
                title.textContent = product.title;
                const meta = document.createElement('span');
                meta.textContent = [product.priceWording, product.price, product.marketPrice && product.marketPrice !== product.price ? `原价 ${product.marketPrice}` : '', product.productId ? `ID ${product.productId}` : ''].filter(Boolean).join(' · ');
                details.append(title, meta);
                card.appendChild(details);
                if (product.appid && product.path) {
                    const copy = document.createElement('button');
                    copy.type = 'button';
                    copy.textContent = '复制商品入口';
                    copy.addEventListener('click', async () => {
                        try {
                            await navigator.clipboard.writeText(`appid: ${product.appid}\npath: ${product.path}`);
                            showToast('商品小程序入口已复制');
                        } catch (_) {
                            showToast('复制失败，请刷新页面后重试', 'error');
                        }
                    });
                    card.appendChild(copy);
                }
                section.appendChild(card);
            });
        }
        row.appendChild(section);
    }

    function renderLiveSearchResults() {
        const container = elements['live-search-results'];
        const fragment = document.createDocumentFragment();
        if (!state.liveSearchItems.length) {
            const empty = document.createElement('div');
            empty.className = 'live-search-empty';
            empty.textContent = state.liveSearchBusy ? '正在读取微信直播结果…' : '暂未搜索';
            fragment.appendChild(empty);
        }
        state.liveSearchItems.forEach((item) => {
            const row = document.createElement('article');
            row.className = `live-search-item${item.isLive ? ' is-live' : ''}`;

            const avatar = document.createElement('div');
            avatar.className = 'live-search-avatar';
            if (item.avatar) {
                const image = document.createElement('img');
                image.src = item.avatar;
                image.alt = '';
                image.loading = 'lazy';
                image.referrerPolicy = 'no-referrer';
                avatar.appendChild(image);
            } else {
                const fallback = document.createElement('span');
                fallback.textContent = item.nickname.slice(0, 1);
                avatar.appendChild(fallback);
            }

            const copy = document.createElement('div');
            copy.className = 'live-search-copy';
            const nameLine = document.createElement('div');
            nameLine.className = 'live-search-name-line';
            const name = document.createElement('strong');
            name.textContent = item.nickname;
            const status = document.createElement('span');
            status.className = `live-search-status${item.isLive ? ' active' : ''}`;
            status.textContent = item.isLive ? '直播中' : '未开播';
            nameLine.append(name, status);
            if (item.productStatus === 'ready') {
                const productStatus = document.createElement('span');
                productStatus.className = 'live-search-status product';
                productStatus.textContent = `带货 ${item.products.length} 件`;
                nameLine.appendChild(productStatus);
            }
            const description = document.createElement('p');
            description.textContent = item.profession || item.signature || '暂无主播简介';
            const meta = document.createElement('div');
            meta.className = 'live-search-meta';
            const facts = [];
            if (item.isLive && item.viewers) facts.push(`观看 ${item.viewers}`);
            if (item.isLive && item.likes) facts.push(`点赞 ${formatCompact(item.likes)}`);
            if (item.liveId) facts.push(`Live ID ${item.liveId}`);
            facts.push(`抓取 ${formatDateTime(item.capturedAt)}`);
            facts.forEach((fact) => {
                const span = document.createElement('span');
                span.textContent = fact;
                meta.appendChild(span);
            });
            copy.append(nameLine, description, meta);

            const actions = document.createElement('div');
            actions.className = 'live-search-actions';
            if (item.streamUrl) {
                const copyStream = document.createElement('button');
                copyStream.type = 'button';
                copyStream.textContent = '复制直播流';
                copyStream.addEventListener('click', async () => {
                    try {
                        await navigator.clipboard.writeText(item.streamUrl);
                        showToast(`已复制“${item.nickname}”的临时直播流`);
                    } catch (_) {
                        showToast('复制失败，请刷新页面后重试', 'error');
                    }
                });
                actions.appendChild(copyStream);
            }
            if (item.username) {
                const copyAccount = document.createElement('button');
                copyAccount.type = 'button';
                copyAccount.textContent = '复制账号 ID';
                copyAccount.addEventListener('click', async () => {
                    try {
                        await navigator.clipboard.writeText(item.username);
                        showToast('主播账号 ID 已复制');
                    } catch (_) {
                        showToast('复制失败，请刷新页面后重试', 'error');
                    }
                });
                actions.appendChild(copyAccount);
            }
            row.append(avatar, copy, actions);
            appendLiveProducts(row, item);
            fragment.appendChild(row);
        });
        container.replaceChildren(fragment);
        const liveCount = state.liveSearchItems.filter((item) => item.isLive).length;
        elements['live-search-count'].textContent = state.liveSearchItems.length
            ? `${state.liveSearchItems.length} 位主播 · ${liveCount} 位直播中`
            : '';
        elements['live-search-more'].hidden = !state.liveSearchHasMore;
    }

    async function searchLiveAnchors({ append = false } = {}) {
        if (state.liveSearchBusy) return;
        const keyword = elements['live-search-keyword'].value.trim();
        if (!keyword) {
            elements['live-search-message'].textContent = '请先输入主播或品牌关键词。';
            elements['live-search-message'].classList.add('error');
            elements['live-search-keyword'].focus();
            return;
        }
        if (!append || keyword !== state.liveSearchKeyword) {
            append = false;
            state.liveSearchKeyword = keyword;
            state.liveSearchNextMarker = '';
            state.liveSearchHasMore = false;
            state.liveSearchItems = [];
        }
        state.liveSearchBusy = true;
        elements['live-search-keyword'].disabled = true;
        elements['live-search-start'].disabled = true;
        elements['live-search-more'].disabled = true;
        elements['live-search-message'].classList.remove('error');
        elements['live-search-message'].textContent = append ? '正在继续读取下一页…' : `正在搜索“${keyword}”的直播主播…`;
        renderLiveSearchResults();
        try {
            const params = new URLSearchParams({
                keyword,
                type: '2',
                page: append ? '2' : '1',
                page_size: '20',
            });
            if (append && state.liveSearchNextMarker) params.set('next_marker', state.liveSearchNextMarker);
            let result;
            try {
                const response = await apiFetch(`/api/channels/contact/search?${params.toString()}`);
                const payload = await response.json();
                result = readLiveSearchResult(payload);
            } catch (searchError) {
                if (append) throw searchError;
                result = await readStoredLiveSearchResult(keyword);
            }
            result = await refreshLiveSearchMetadata(result);
            mergeLiveSearchItems(result, append);
            state.liveSearchNextMarker = result.nextMarker;
            state.liveSearchHasMore = result.hasMore && Boolean(result.nextMarker);
            const liveCount = state.liveSearchItems.filter((item) => item.isLive).length;
            elements['live-search-message'].textContent = `已读取 ${state.liveSearchItems.length} 位主播，其中 ${liveCount} 位正在直播。`;
            await hydrateLiveShopShelves(state.liveSearchItems);
            const productLiveCount = state.liveSearchItems.filter((item) => item.products?.length).length;
            const savedSnapshots = await persistLiveSnapshots(state.liveSearchItems);
            elements['live-search-message'].textContent = `已读取 ${state.liveSearchItems.length} 位主播，其中 ${liveCount} 位正在直播，${productLiveCount} 位已识别直播商品，已保存 ${savedSnapshots} 条观看人数快照。`;
        } catch (error) {
            elements['live-search-message'].textContent = error.message;
            elements['live-search-message'].classList.add('error');
        } finally {
            state.liveSearchBusy = false;
            elements['live-search-keyword'].disabled = false;
            elements['live-search-start'].disabled = false;
            elements['live-search-more'].disabled = false;
            renderLiveSearchResults();
        }
    }

    async function startAutomation() {
        if (state.automationBusy) return;
        const maxItems = Math.min(200, Math.max(1, Number(elements['automation-target'].value) || 20));
        state.automationBusy = true;
        const controller = new AbortController();
        state.feedImportController = controller;
        clearInterval(state.automationTimer);
        state.automationTimer = null;
        elements['automation-target'].disabled = true;
        elements['automation-start'].disabled = true;
        elements['automation-start'].textContent = '接口采集中…';
        elements['automation-message'].classList.remove('error');
        elements['automation-message'].textContent = '正在通过推荐接口读取 Feed；接口尚未初始化时最多尝试切换 3 次…';
        try {
            const response = await apiFetch('/api/insights/feed/import', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ maxItems, allowPageFallback: true }),
                signal: controller.signal,
            });
            const payload = await response.json();
            const result = payload.data || {};
            const fetched = Number(result.fetched) || 0;
            const productCount = Array.isArray(result.items) ? result.items.filter((item) => item.hasProduct).length : 0;
            const fallbackText = result.fallbackUsed ? '，首次使用了页面初始化兜底' : '，全程接口直拉';
            elements['automation-progress-text'].textContent = `${fetched} / ${maxItems}`;
            elements['automation-progress-bar'].style.width = `${Math.min(100, Math.round((fetched / maxItems) * 100))}%`;
            elements['automation-message'].textContent = `完成：读取 ${fetched} 条，新增 ${result.created || 0} 条，更新 ${result.updated || 0} 条，识别带货 ${productCount} 条${fallbackText}。`;
            showToast(`推荐流已采集 ${fetched} 条`);
            state.page = 1;
            await loadWorkspace();
        } catch (error) {
            if (error.name === 'AbortError') {
                elements['automation-message'].textContent = '推荐流采集与商品详情核验已停止。';
            } else {
                elements['automation-message'].textContent = error.message;
                elements['automation-message'].classList.add('error');
                showToast(error.message, 'error');
            }
        } finally {
            state.automationBusy = false;
            if (state.feedImportController === controller) state.feedImportController = null;
            elements['automation-target'].disabled = false;
            elements['automation-start'].disabled = false;
            elements['automation-start'].textContent = '开始接口采集';
        }
    }

    function bindEvents() {
        elements['search-input'].addEventListener('input', (event) => {
            clearTimeout(state.searchTimer);
            state.searchTimer = setTimeout(() => {
                state.query = event.target.value.trim();
                state.page = 1;
                loadWorkspace();
            }, 280);
        });
        elements['author-filter'].addEventListener('change', (event) => {
            state.author = event.target.value;
            state.page = 1;
            loadWorkspace();
        });
        elements['product-filter'].addEventListener('change', (event) => {
            state.product = event.target.value || 'all';
            state.page = 1;
            loadWorkspace();
        });
        elements['ad-filter'].addEventListener('change', (event) => {
            state.ad = event.target.value || 'all';
            state.page = 1;
            loadWorkspace();
        });
        elements['days-filter'].addEventListener('change', (event) => {
            state.days = Number(event.target.value) || 30;
            state.page = 1;
            loadWorkspace();
        });
        elements['sort-filter'].addEventListener('change', (event) => {
            state.sort = event.target.value || 'published_desc';
            state.page = 1;
            loadWorkspace({ preserveSelection: true });
        });
        elements['previous-page'].addEventListener('click', () => {
            if (state.page <= 1) return;
            state.page -= 1;
            loadWorkspace();
        });
        elements['next-page'].addEventListener('click', () => {
            if (state.page >= state.totalPages) return;
            state.page += 1;
            loadWorkspace();
        });
        elements['refresh-button'].addEventListener('click', () => loadWorkspace({ preserveSelection: true }));
        elements['play-video'].addEventListener('click', playSelectedVideo);
        elements['copy-video-link'].addEventListener('click', copyVideoLink);
        elements['download-video'].addEventListener('click', () => startMediaAction('download'));
        elements['transcribe-video'].addEventListener('click', () => startMediaAction('transcribe'));
        elements['copy-transcript'].addEventListener('click', copyTranscript);
        elements['player-close'].addEventListener('click', closePlayer);
        elements['player-modal'].addEventListener('click', (event) => {
            if (event.target === elements['player-modal']) closePlayer();
        });
        elements['insight-player'].addEventListener('loadedmetadata', () => {
            elements['player-status'].textContent = state.playerRefreshAttempted ? '链接已刷新，可以播放。' : '在线播放连接正常。';
            elements['player-status'].classList.remove('error');
        });
        elements['insight-player'].addEventListener('error', handlePlayerError);
        elements['export-button'].addEventListener('click', exportData);
        elements['nav-export'].addEventListener('click', exportData);
        elements['nav-update'].addEventListener('click', openUpdateModal);
        elements['nav-auto-browse'].addEventListener('click', openAutomationModal);
        elements['nav-stop-auto-browse'].addEventListener('click', () => automationControl('stop'));
        elements['nav-search-import'].addEventListener('click', openSearchImportModal);
        elements['nav-account-download'].addEventListener('click', openAccountDownloadModal);
        elements['nav-live-search'].addEventListener('click', openLiveSearchModal);
        elements['nav-live-library'].addEventListener('click', openLiveLibraryModal);
        elements['update-install'].addEventListener('click', installUpdate);
        elements['update-close'].addEventListener('click', closeUpdateModal);
        elements['update-close-icon'].addEventListener('click', closeUpdateModal);
        elements['update-modal'].addEventListener('click', (event) => {
            if (event.target === elements['update-modal']) closeUpdateModal();
        });
        elements['automation-start'].addEventListener('click', startAutomation);
        elements['automation-pause'].addEventListener('click', () => automationControl('pause'));
        elements['automation-resume'].addEventListener('click', () => automationControl('resume'));
        elements['automation-stop'].addEventListener('click', () => automationControl('stop'));
        elements['automation-close'].addEventListener('click', closeAutomationModal);
        elements['automation-close-icon'].addEventListener('click', closeAutomationModal);
        elements['automation-modal'].addEventListener('click', (event) => {
            if (event.target === elements['automation-modal']) closeAutomationModal();
        });
        elements['search-import-start'].addEventListener('click', startSearchImport);
        elements['search-import-close'].addEventListener('click', closeSearchImportModal);
        elements['search-import-close-icon'].addEventListener('click', closeSearchImportModal);
        elements['search-import-keyword'].addEventListener('keydown', (event) => {
            if (event.key === 'Enter') startSearchImport();
        });
        elements['search-import-modal'].addEventListener('click', (event) => {
            if (event.target === elements['search-import-modal']) closeSearchImportModal();
        });
        elements['account-download-search'].addEventListener('click', searchDownloadAccounts);
        elements['account-download-keyword'].addEventListener('keydown', (event) => {
            if (event.key === 'Enter') searchDownloadAccounts();
        });
        elements['account-download-close'].addEventListener('click', closeAccountDownloadModal);
        elements['account-download-close-icon'].addEventListener('click', closeAccountDownloadModal);
        elements['account-download-modal'].addEventListener('click', (event) => {
            if (event.target === elements['account-download-modal']) closeAccountDownloadModal();
        });
        elements['account-select-latest'].addEventListener('click', selectLatestAccountVideos);
        elements['account-select-all'].addEventListener('click', selectAllAccountVideos);
        elements['account-clear-selection'].addEventListener('click', clearAccountVideoSelection);
        elements['account-download-more'].addEventListener('click', () => loadAccountVideos({ append: true }));
        elements['account-download-start'].addEventListener('click', startSelectedAccountDownloads);
        elements['account-download-cancel'].addEventListener('click', cancelAccountDownloads);
        elements['live-search-start'].addEventListener('click', () => searchLiveAnchors());
        elements['live-search-more'].addEventListener('click', () => searchLiveAnchors({ append: true }));
        elements['live-search-close'].addEventListener('click', closeLiveSearchModal);
        elements['live-search-close-icon'].addEventListener('click', closeLiveSearchModal);
        elements['live-search-keyword'].addEventListener('keydown', (event) => {
            if (event.key === 'Enter') searchLiveAnchors();
        });
        elements['live-search-modal'].addEventListener('click', (event) => {
            if (event.target === elements['live-search-modal']) closeLiveSearchModal();
        });
        elements['live-library-add'].addEventListener('click', addLiveLibraryTarget);
        elements['live-library-refresh'].addEventListener('click', () => loadLiveLibraryTargets({ refreshHistory: true }));
        elements['live-library-close'].addEventListener('click', closeLiveLibraryModal);
        elements['live-library-close-icon'].addEventListener('click', closeLiveLibraryModal);
        elements['live-library-keyword'].addEventListener('keydown', (event) => {
            if (event.key === 'Enter') addLiveLibraryTarget();
        });
        elements['live-library-modal'].addEventListener('click', (event) => {
            if (event.target === elements['live-library-modal']) closeLiveLibraryModal();
        });
        elements['collapse-sidebar'].addEventListener('click', () => document.body.classList.toggle('sidebar-collapsed'));
        elements['mobile-menu'].addEventListener('click', () => document.body.classList.toggle('sidebar-open'));
        elements['detail-close'].addEventListener('click', () => document.body.classList.remove('detail-open'));
        document.querySelectorAll('.primary-nav a').forEach((link) => {
            link.addEventListener('click', () => document.body.classList.remove('sidebar-open'));
        });
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                document.body.classList.remove('sidebar-open', 'detail-open');
                closeUpdateModal();
                closeAutomationModal();
                closeSearchImportModal();
                closeAccountDownloadModal();
                closeLiveSearchModal();
                closeLiveLibraryModal();
                closePlayer();
            }
        });
    }

    function init() {
        cacheElements();
        bindEvents();
        checkConnection();
        loadWorkspace();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init, { once: true });
    } else {
        init();
    }
})();

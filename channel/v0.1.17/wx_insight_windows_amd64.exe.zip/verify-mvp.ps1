﻿param(
    [string]$BaseUrl = 'http://127.0.0.1:2025',
    [string]$Token = '',
    [switch]$RequireData,
    [switch]$RequireAutomation
)

$ErrorActionPreference = 'Stop'
$BaseUrl = $BaseUrl.TrimEnd('/')
$headers = @{}
if (-not [string]::IsNullOrWhiteSpace($Token)) {
    $headers['X-Local-Auth'] = $Token
}

function Get-MvpResponse {
    param([Parameter(Mandatory = $true)][string]$Path)
    return Invoke-WebRequest -UseBasicParsing -Uri "$BaseUrl$Path" -Headers $headers -TimeoutSec 10
}

function Get-MvpJson {
    param([Parameter(Mandatory = $true)][string]$Path)
    $response = Get-MvpResponse -Path $Path
    if ($response.StatusCode -ne 200) {
        throw "$Path 返回 HTTP $($response.StatusCode)"
    }
    return $response.Content | ConvertFrom-Json
}

Write-Host '==> 检查工作台页面和静态资源' -ForegroundColor Cyan
$page = Get-MvpResponse -Path '/insight'
if ($page.StatusCode -ne 200 -or $page.Content -notmatch '<title>微信洞察</title>') {
    throw '/insight 没有返回预期的微信洞察页面。'
}
$null = Get-MvpResponse -Path '/css/insight.css'
$null = Get-MvpResponse -Path '/js/insight.js'

Write-Host '==> 检查采集器健康状态' -ForegroundColor Cyan
$health = Get-MvpJson -Path '/api/health'
if ($health.code -ne 0 -or $health.data.status -ne 'ok') {
    throw '/api/health 没有返回预期健康状态。'
}

Write-Host '==> 读取真实洞察数据' -ForegroundColor Cyan
$workspace = Get-MvpJson -Path '/api/insights?days=3650&page=1&pageSize=10'
if ($workspace.code -ne 0 -or $null -eq $workspace.data.summary -or $null -eq $workspace.data.items) {
    throw '/api/insights 返回结构不符合 MVP 约定。'
}

$totalVideos = [int]$workspace.data.summary.totalVideos
$totalEngagement = [long]$workspace.data.summary.totalEngagement
Write-Host "真实返回：视频数=$totalVideos，总互动=$totalEngagement" -ForegroundColor Green

if ($RequireData -and $totalVideos -lt 1) {
    throw 'RequireData 已启用，但数据库里没有真实视频。请先在微信视频号浏览并采集至少一条内容。'
}

if ($workspace.data.items.Count -gt 0) {
    $first = $workspace.data.items[0]
    $detail = Get-MvpJson -Path ("/api/insights/" + [uri]::EscapeDataString([string]$first.id))
    if ($detail.code -ne 0 -or $detail.data.id -ne $first.id) {
        throw '详情接口没有返回列表中的真实记录。'
    }
    Write-Host "真实记录：id=$($first.id)，标题=$($first.title)，综合分=$($first.score)，评论可用=$($detail.data.commentsAvailable)" -ForegroundColor Green
}

Write-Host '==> 检查自动采集控制面' -ForegroundColor Cyan
$automation = Get-MvpJson -Path '/api/automation/status'
if ($automation.code -ne 0 -or $null -eq $automation.data.state -or $null -eq $automation.data.agentConnected) {
    throw '/api/automation/status 返回结构不符合 MVP 约定。'
}
Write-Host "自动采集状态：state=$($automation.data.state)，视频号页面已连接=$($automation.data.agentConnected)" -ForegroundColor Green

if ($RequireAutomation) {
    if (-not [bool]$automation.data.agentConnected) {
        throw 'RequireAutomation 已启用，但未检测到视频号页面。请先打开微信视频号推荐、关注或朋友页面。'
    }

    Write-Host '==> 真测自动切换 2 条视频（每条停留 3 秒）' -ForegroundColor Cyan
    $controlHeaders = @{} + $headers
    $controlHeaders['X-WX-Insight-Automation'] = 'control'
    $startBody = @{ targetCount = 2; minDwellSeconds = 3; maxDwellSeconds = 3 } | ConvertTo-Json -Compress
    $started = Invoke-RestMethod -Method Post -Uri "$BaseUrl/api/automation/start" -Headers $controlHeaders -ContentType 'application/json' -Body $startBody -TimeoutSec 10
    if ($started.code -ne 0 -or $started.data.state -notin @('running', 'completed')) {
        throw '自动采集启动失败。'
    }

    $deadline = (Get-Date).AddSeconds(30)
    do {
        Start-Sleep -Seconds 1
        $automation = Get-MvpJson -Path '/api/automation/status'
        if ($automation.data.state -in @('completed', 'error', 'stopped')) { break }
    } while ((Get-Date) -lt $deadline)

    if ($automation.data.state -ne 'completed' -or [int]$automation.data.viewedCount -ne 2) {
        try {
            $null = Invoke-RestMethod -Method Post -Uri "$BaseUrl/api/automation/stop" -Headers $controlHeaders -ContentType 'application/json' -Body '{}' -TimeoutSec 10
        } catch {}
        throw "自动切换真测未完成：state=$($automation.data.state)，viewedCount=$($automation.data.viewedCount)，lastError=$($automation.data.lastError)"
    }
    Write-Host "自动切换真实完成：state=$($automation.data.state)，viewedCount=$($automation.data.viewedCount)" -ForegroundColor Green
}

Write-Host '==> wx_insight 第一阶段接口验收完成' -ForegroundColor Green

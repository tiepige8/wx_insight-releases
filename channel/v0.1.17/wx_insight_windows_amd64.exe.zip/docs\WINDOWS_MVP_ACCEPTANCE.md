# wx_insight Windows MVP 构建与验收

## 分工

- Mac：开发页面、接口和洞察计算，执行不依赖微信进程的检查；
- Windows：原生构建采集器，并连接真实微信视频号完成端到端验收。

Mac 上不交付降级版采集器。第一阶段最终运行包以 Windows `amd64` 为准。

## Windows 构建

构建环境沿用原项目要求：Go、GCC/MinGW 和 PowerShell。进入仓库根目录后运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build-mvp.ps1
```

输出文件：

```text
release\wx_insight_mvp_windows_amd64\wx_insight_mvp_windows_amd64.zip
release\wx_insight_mvp_windows_amd64\wx_insight_windows_amd64.exe.zip
release\wx_insight_mvp_windows_amd64\wx_insight_windows_amd64.exe.zip.sha256
```

运行包包含 `wx_channel.exe`、配置示例、`web` 静态资源备份、验收脚本和本说明。正式页面资源已经嵌入 exe，后续自更新只需替换 exe。

其中后两个文件是自更新资产：发布新版本时必须同时上传 ZIP 和对应 `.sha256`。应用只会安装 SHA256 校验通过的更新。

## 真实验收

1. 解压运行包，启动 `wx_channel.exe`；
2. 在微信视频号中打开“推荐”“关注”或“朋友”视频流，确认自动采集面板显示“视频号页面已连接”；
3. 可以先手动浏览至少一条内容，确认原采集功能产生浏览记录；
4. 如需评论洞察，对其中一条内容完成评论获取；
5. 浏览器打开 `http://127.0.0.1:2025/insight`；
6. 在解压目录执行：

```powershell
powershell -ExecutionPolicy Bypass -File .\verify-mvp.ps1 -RequireData
```

真测自动切换两条视频：

```powershell
powershell -ExecutionPolicy Bypass -File .\verify-mvp.ps1 -RequireData -RequireAutomation
```

`RequireAutomation` 会明确启动一个 2 条、每条停留 3 秒的任务。它只切换视频，不执行点赞、评论、收藏或关注。

如果配置了 `secret_token`，追加：

```powershell
-Token "你的 secret_token"
```

如果修改了代理端口，追加实际地址，例如：

```powershell
-BaseUrl "http://127.0.0.1:3025"
```

## 通过标准

- `/insight`、CSS 和 JavaScript 均返回 HTTP 200；
- `/api/health` 返回 `status=ok`；
- `/api/insights` 返回真实数据库中的视频数和总互动；
- 至少一条列表记录可以通过详情接口按真实 ID 读取；
- 页面上能搜索、筛选、翻页和选择内容；
- 有评论文件时显示已分析评论数和真实关键词，无评论时明确显示缺失状态。
- 自动采集面板可设置条数与停留区间，开始、暂停、继续、停止状态正确；
- 启用 `RequireAutomation` 时，微信页面真实切换一次并返回 `state=completed, viewedCount=2`。

脚本通过只证明本地接口与真实 SQLite 数据可读。还需要人工确认微信进程采集和页面展示，不能把单元测试或 HTTP 健康检查当成完整业务通过。

## 后续更新

首个版本安装后，不再重复复制源码。打开 `/insight`，点击左侧“检查更新”即可：

1. 应用从 `tiepige8/wx_insight-releases` 检查正式版本；
2. 用户明确点击安装后才下载更新；
3. 下载文件必须通过同名 `.sha256` 校验；
4. 只替换 `wx_channel.exe`，不会修改 `downloads`、SQLite、评论文件或配置；
5. 安装完成后关闭并重新打开程序生效。

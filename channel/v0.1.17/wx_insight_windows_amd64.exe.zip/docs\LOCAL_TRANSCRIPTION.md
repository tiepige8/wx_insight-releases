# 本地语音转文字

wx_insight 的转写链路只在本机执行：

1. 使用已经采集到的视频直链保存 MP4；
2. 使用 `ffmpeg` 提取 16kHz、单声道 WAV；
3. 使用 `whisper.cpp` 的 `whisper-cli` 和本地模型生成 TXT。

视频、音频和文字稿不会因为本功能上传到云端。

## Windows 目录约定

将工具放到 `wx_channel.exe` 所在目录：

```text
wx_channel.exe
tools/
  ffmpeg/bin/ffmpeg.exe
  whisper-gpu/runtime/Release/whisper-cli.exe
  whisper/whisper-cli.exe
models/
  ggml-large-v3-turbo-q5_0.bin
```

程序优先使用 `tools/whisper-gpu/runtime/Release/whisper-cli.exe`，没有 GPU 版本时再使用
`tools/whisper/whisper-cli.exe` 或系统 `PATH` 中的程序。NVIDIA 显卡运行时需要与
`whisper.cpp` 发布包匹配的 CUDA DLL 一并保留在 `Release` 目录。

需要使用自定义位置时，可设置：

```text
WX_INSIGHT_FFMPEG
WX_INSIGHT_WHISPER_CLI
WX_INSIGHT_WHISPER_MODEL
WX_INSIGHT_WHISPER_LANGUAGE
```

默认语言为 `zh`。

推荐使用 `large-v3-turbo-q5_0`：它保留 large-v3-turbo 架构，并使用量化权重降低本机内存、磁盘和 CPU 推理压力。

## 本地输出

- 视频：`downloads/<作者>/<标题>_<视频ID>.mp4`
- 音频：`downloads/transcripts/<视频ID>/audio.wav`
- 文字稿：`downloads/transcripts/<视频ID>/transcript.txt`

详情页支持代理在线播放。视频直链过期时，程序会优先使用采集到的分享链接或
`nonce_id` 自动刷新；旧记录缺少这些信息时，仍需在微信里重新打开一次该视频。

检测到明确商品信号的带货视频会自动进入本地转写队列。队列一次只处理一个视频，
避免同时占满 GPU、磁盘和网络；生成后可直接在洞察详情页查看和复制文字稿。

package webassets

import "embed"

// Files 把控制台、洞察工作台及其静态资源打进可执行文件。
// 更新程序只替换 exe，页面会随版本一起更新，不依赖外部 web 目录。
//
//go:embed *.html css js docs icon.png
var Files embed.FS

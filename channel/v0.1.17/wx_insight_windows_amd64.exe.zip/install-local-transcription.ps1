﻿param(
    [string]$InstallDirectory = ''
)

$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($InstallDirectory)) {
    $InstallDirectory = Split-Path -Parent $PSScriptRoot
}
$InstallDirectory = [System.IO.Path]::GetFullPath($InstallDirectory)

$toolsDirectory = Join-Path $InstallDirectory 'tools'
$ffmpegDirectory = Join-Path $toolsDirectory 'ffmpeg\bin'
$whisperDirectory = Join-Path $toolsDirectory 'whisper'
$modelsDirectory = Join-Path $InstallDirectory 'models'
$tempDirectory = Join-Path $InstallDirectory '.transcription-install'

New-Item -ItemType Directory -Force $ffmpegDirectory, $whisperDirectory, $modelsDirectory, $tempDirectory | Out-Null

function Download-Resumable {
    param(
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][string]$Destination,
        [int64]$MinimumBytes = 1
    )
    if ((Test-Path $Destination) -and (Get-Item $Destination).Length -ge $MinimumBytes) {
        Write-Host "Using existing $(Split-Path -Leaf $Destination)." -ForegroundColor DarkCyan
        return
    }
    Write-Host "Downloading $(Split-Path -Leaf $Destination)..." -ForegroundColor Cyan
    & curl.exe -L --fail --retry 5 --retry-delay 3 -C - -o $Destination $Url
    if ($LASTEXITCODE -ne 0) {
        throw "Download failed: $Url"
    }
}

$ffmpegZip = Join-Path $tempDirectory 'ffmpeg-release-essentials.zip'
$whisperZip = Join-Path $tempDirectory 'whisper-bin-x64.zip'
$modelPath = Join-Path $modelsDirectory 'ggml-large-v3-turbo-q5_0.bin'

if (-not (Test-Path (Join-Path $ffmpegDirectory 'ffmpeg.exe'))) {
    Download-Resumable -Url 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip' -Destination $ffmpegZip -MinimumBytes 50MB
    $ffmpegExtract = Join-Path $tempDirectory 'ffmpeg'
    if (Test-Path $ffmpegExtract) { Remove-Item -Recurse -Force $ffmpegExtract }
    Expand-Archive -Path $ffmpegZip -DestinationPath $ffmpegExtract -Force
    $ffmpegExe = Get-ChildItem $ffmpegExtract -Recurse -Filter 'ffmpeg.exe' | Select-Object -First 1
    if ($null -eq $ffmpegExe) { throw 'ffmpeg.exe was not found in the official archive.' }
    Copy-Item -Force (Join-Path $ffmpegExe.Directory.FullName '*') $ffmpegDirectory
}

if (-not (Test-Path (Join-Path $whisperDirectory 'whisper-cli.exe'))) {
    Download-Resumable -Url 'https://github.com/ggml-org/whisper.cpp/releases/download/v1.9.1/whisper-bin-x64.zip' -Destination $whisperZip -MinimumBytes 5MB
    $expectedWhisperHash = '7d8be46ecd31828e1eb7a2ecdd0d6b314feafd82163038ab6092594b0a063539'
    $actualWhisperHash = (Get-FileHash -Algorithm SHA256 $whisperZip).Hash.ToLowerInvariant()
    if ($actualWhisperHash -ne $expectedWhisperHash) {
        throw "whisper.cpp archive checksum mismatch: $actualWhisperHash"
    }
    $whisperExtract = Join-Path $tempDirectory 'whisper'
    if (Test-Path $whisperExtract) { Remove-Item -Recurse -Force $whisperExtract }
    Expand-Archive -Path $whisperZip -DestinationPath $whisperExtract -Force
    $whisperExe = Get-ChildItem $whisperExtract -Recurse -Filter 'whisper-cli.exe' | Select-Object -First 1
    if ($null -eq $whisperExe) { throw 'whisper-cli.exe was not found in the official archive.' }
    Copy-Item -Recurse -Force (Join-Path $whisperExe.Directory.FullName '*') $whisperDirectory
}

if (-not (Test-Path $modelPath)) {
    Download-Resumable -Url 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo-q5_0.bin?download=true' -Destination $modelPath -MinimumBytes 100MB
}

$ffmpegExePath = Join-Path $ffmpegDirectory 'ffmpeg.exe'
$whisperExePath = Join-Path $whisperDirectory 'whisper-cli.exe'
if (-not (Test-Path $ffmpegExePath)) { throw 'ffmpeg installation verification failed.' }
if (-not (Test-Path $whisperExePath)) { throw 'whisper.cpp installation verification failed.' }
if ((Get-Item $modelPath).Length -lt 100MB) { throw 'Whisper model file is unexpectedly small.' }

Write-Host "FFmpeg: $ffmpegExePath" -ForegroundColor Green
Write-Host "Whisper: $whisperExePath" -ForegroundColor Green
Write-Host "Model: $modelPath" -ForegroundColor Green
Write-Host 'Local transcription dependencies installed.' -ForegroundColor Green

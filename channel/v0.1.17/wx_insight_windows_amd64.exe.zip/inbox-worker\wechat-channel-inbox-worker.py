#!/usr/bin/env python3
"""Read-only WeChat 4.x inbox listener for forwarded Channels cards.

The worker reads SQLCipher message databases through the vendored wechatauto
reader, extracts only Finder video card metadata, and submits it to wx_insight.
It never persists ordinary chat message text and performs no UI automation.
"""

from __future__ import annotations

import argparse
import html
import importlib.util
import json
import logging
from logging.handlers import RotatingFileHandler
import os
import re
import signal
import sys
import threading
import time
import urllib.error
import urllib.request


STATE_VERSION = 4
DEFAULT_API = "http://127.0.0.1:2026"
DEFAULT_BACKFILL = 0
MAX_XML_BYTES = 4_000_000


def tag_value(xml: str, *names: str) -> str:
    for name in names:
        match = re.search(
            rf"<{re.escape(name)}(?:\s[^>]*)?>\s*(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?\s*</{re.escape(name)}>",
            xml,
            re.IGNORECASE | re.DOTALL,
        )
        if match:
            return html.unescape(match.group(1).strip())
    return ""


def tag_block(xml: str, name: str) -> str:
    match = re.search(
        rf"<{re.escape(name)}(?:\s[^>]*)?>(.*?)</{re.escape(name)}>",
        xml,
        re.IGNORECASE | re.DOTALL,
    )
    return match.group(1) if match else ""


def integer(value: str) -> int:
    try:
        return int(float(value.strip()))
    except (AttributeError, TypeError, ValueError):
        return 0


def decompress_xml(value) -> str:
    if not value:
        return ""
    if isinstance(value, str):
        return value
    if value.startswith(b"\x28\xb5\x2f\xfd"):
        import zstandard

        value = zstandard.ZstdDecompressor().decompress(value, max_output_size=MAX_XML_BYTES)
    return value.decode("utf-8", "ignore")


def extract_finder_video_card(row: dict) -> dict | None:
    candidates = (row.get("content"), row.get("compress_content"))
    decoded_candidates = []
    for candidate in candidates:
        decoded = decompress_xml(candidate)
        if "finderfeed" in decoded.lower():
            media = tag_block(tag_block(tag_block(decoded, "finderFeed"), "mediaList"), "media")
            media_url = tag_value(media, "url")
            score = 1
            if tag_value(media, "urlToken") or tag_value(media, "decodeKey", "decryptKey"):
                score += 4
            if "token=" in media_url.lower():
                score += 8
            decoded_candidates.append((score, len(decoded), decoded))
    xml = max(decoded_candidates, default=(0, 0, ""))[2]
    if not xml:
        return None

    finder_feed = tag_block(xml, "finderFeed")
    media = tag_block(tag_block(finder_feed, "mediaList"), "media")
    object_id = tag_value(finder_feed, "objectId", "objectid")
    nonce_id = tag_value(finder_feed, "objectNonceId", "nonceId", "nonceid")
    appmsg_type = tag_value(xml, "type")
    feed_type = tag_value(finder_feed, "feedType")
    media_type = tag_value(media, "mediaType")

    # appmsg type 51 + Finder feed/media type 4 is a forwarded short video.
    # Other type-49 cards (articles, mini programs, operator invitations) are ignored.
    if appmsg_type != "51" or feed_type != "4" or media_type != "4":
        return None
    if not object_id or not nonce_id:
        return None

    return {
        "objectId": object_id,
        "nonceId": nonce_id,
        "finderUsername": tag_value(finder_feed, "username", "finderUsername"),
        "nickname": tag_value(finder_feed, "nickname"),
        "description": tag_value(finder_feed, "desc", "description"),
        "mediaUrl": tag_value(media, "url"),
        "urlToken": tag_value(media, "urlToken"),
        "decryptKey": tag_value(media, "decodeKey", "decryptKey"),
        "coverUrl": tag_value(media, "coverUrl", "thumbUrl"),
        "width": integer(tag_value(media, "width")),
        "height": integer(tag_value(media, "height")),
        "messageTime": integer(str(row.get("create_time") or "")),
        "autoTranscribe": True,
    }


def load_module(path: str):
    spec = importlib.util.spec_from_file_location("wx_insight_wechat_db", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load WeChat DB reader: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def read_json(path: str, default):
    try:
        with open(path, "r", encoding="utf-8") as source:
            return json.load(source)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return default


def atomic_write_json(path: str, value) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    temporary = path + ".tmp"
    with open(temporary, "w", encoding="utf-8") as output:
        json.dump(value, output, ensure_ascii=False, indent=2, sort_keys=True)
        output.flush()
        os.fsync(output.fileno())
    os.replace(temporary, path)


def normalize_state(value) -> dict:
    state = value if isinstance(value, dict) else {}
    previous_version = integer(str(state.get("version") or "0"))
    state.setdefault("watermarks", {})
    state.setdefault("watermarkLocalIds", {})
    state.setdefault("processed", {})
    state.setdefault("accepted", {})
    state.setdefault("pending", {})
    if previous_version < 3:
        # Versions 1/2 may contain a watermark produced by the old historical
        # backfill implementation and stale jobs from unrelated test imports.
        # Preserve the completed audit trail but establish a clean inbox epoch.
        state["watermarks"] = {}
        state["watermarkLocalIds"] = {}
        state["accepted"] = {}
        state["pending"] = {}
        state["migratedAt"] = int(time.time())
    elif previous_version < STATE_VERSION:
        # v3 jobs did not persist the source conversation, so they cannot be
        # proven to belong to the current whitelist. Quarantine them instead
        # of silently downloading material from an old account/session.
        state["accepted"] = {}
        state["pending"] = {}
        state["queueScopeMigratedAt"] = int(time.time())
    state["version"] = STATE_VERSION
    return state


def find_secret_token(config_path: str) -> str:
    token = os.environ.get("WX_INSIGHT_SECRET_TOKEN", "").strip()
    if token:
        return token
    try:
        with open(config_path, "r", encoding="utf-8-sig") as source:
            for line in source:
                match = re.match(r"^\s*secret_token\s*:\s*(.*?)\s*$", line)
                if match:
                    return match.group(1).strip().strip("'\"")
    except OSError:
        pass
    return ""


class InboxWorker:
    def __init__(self, args, db_module):
        self.args = args
        self.db_module = db_module
        self.stop_event = threading.Event()
        self.state_lock = threading.RLock()
        self.state = normalize_state(read_json(args.state, {}))
        self.sessions = {
            value.strip()
            for value in str(args.sessions or "").split(",")
            if value.strip()
        }
        self.token = find_secret_token(args.config)
        self.db = db_module.WeChatDB(
            db_dir=args.db_root,
            account=args.account or None,
            workdir=args.cache,
        )

    def save_state(self) -> None:
        with self.state_lock:
            atomic_write_json(self.args.state, self.state)

    def prune_unscoped_queues(self) -> None:
        if not self.sessions:
            return
        removed = 0
        with self.state_lock:
            for queue_name in ("accepted", "pending"):
                queue = self.state[queue_name]
                for object_id, value in list(queue.items()):
                    card = (value or {}).get("card") or {}
                    source_session = str(card.get("sourceSession") or "").strip()
                    if source_session not in self.sessions:
                        queue.pop(object_id, None)
                        removed += 1
        if removed:
            self.save_state()
            logging.warning("已隔离不属于当前会话白名单的旧任务 count=%d", removed)

    def api_import(self, card: dict) -> dict:
        body = json.dumps(card, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            self.args.api.rstrip("/") + "/api/insights/inbox/import",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        if self.token:
            request.add_header("X-Local-Auth", self.token)
        with urllib.request.urlopen(request, timeout=self.args.api_timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
        if payload.get("success") is False or ("code" in payload and payload.get("code") != 0):
            raise RuntimeError(payload.get("error") or payload.get("message") or "wx_insight API returned an error")
        return payload.get("data") or {}

    def api_media_status(self, object_id: str) -> dict:
        request = urllib.request.Request(
            self.args.api.rstrip("/") + f"/api/insights/{object_id}/media/status",
            headers={},
            method="GET",
        )
        if self.token:
            request.add_header("X-Local-Auth", self.token)
        with urllib.request.urlopen(request, timeout=10) as response:
            payload = json.loads(response.read().decode("utf-8"))
        if payload.get("success") is False or ("code" in payload and payload.get("code") != 0):
            raise RuntimeError(payload.get("error") or payload.get("message") or "wx_insight status API returned an error")
        return payload.get("data") or {}

    def submit(self, card: dict) -> bool:
        object_id = card["objectId"]
        source_session = str(card.get("sourceSession") or "").strip()
        if self.sessions and source_session not in self.sessions:
            logging.warning("忽略非白名单会话卡片 objectId=%s sourceSession=%s", object_id, source_session or "missing")
            return True
        with self.state_lock:
            if object_id in self.state["processed"]:
                return True
            if object_id in self.state["accepted"]:
                return True
        try:
            result = self.api_import(card)
        except (OSError, ValueError, RuntimeError, urllib.error.HTTPError) as exc:
            logging.warning("卡片导入失败 objectId=%s error=%s", object_id, exc)
            with self.state_lock:
                pending = self.state["pending"].setdefault(object_id, {"card": card, "attempts": 0})
                pending["attempts"] = int(pending.get("attempts", 0)) + 1
                pending["lastError"] = str(exc)
                pending["lastAttemptAt"] = int(time.time())
            self.save_state()
            return False

        if not result.get("resolved"):
            reason = result.get("pendingReason") or "视频号详情刷新接口尚未就绪"
            logging.info("卡片等待接口刷新 objectId=%s reason=%s", object_id, reason)
            with self.state_lock:
                pending = self.state["pending"].setdefault(object_id, {"card": card, "attempts": 0})
                pending["attempts"] = int(pending.get("attempts", 0)) + 1
                pending["lastError"] = reason
                pending["lastAttemptAt"] = int(time.time())
            self.save_state()
            return False

        stage = (result.get("media") or {}).get("stage", "queued")
        with self.state_lock:
            previous = self.state["pending"].get(object_id) or {}
            target = self.state["processed"] if stage == "completed" else self.state["accepted"]
            target[object_id] = {
                "author": card.get("nickname", ""),
                "acceptedAt": int(time.time()),
                "stage": stage,
                "card": card,
                "attempts": int(previous.get("attempts", 0)),
            }
            self.state["pending"].pop(object_id, None)
        self.save_state()
        logging.info("视频号卡片已进入处理队列 objectId=%s author=%s stage=%s", object_id, card.get("nickname", ""), stage)
        return True

    def process_row(self, row: dict, source_session: str) -> None:
        try:
            card = extract_finder_video_card(row)
        except Exception as exc:
            logging.warning("卡片 XML 解析失败 localId=%s error=%s", row.get("local_id"), exc)
            return
        if card is not None:
            card["sourceSession"] = source_session
            self.submit(card)

    def on_message(self, message: dict, _listener) -> None:
        if message.get("type") != "文件/链接/卡片":
            return
        row = self.db.get_message_row(message["username"], message["local_id"])
        if not row:
            raise RuntimeError(f"message row is not ready: {message['username']}#{message['local_id']}")
        self.process_row(row, message["username"])

    def active_sessions(self) -> list[str]:
        if self.sessions:
            return sorted(self.sessions)
        if not self.args.allow_all_sessions:
            raise RuntimeError("未配置会话白名单；请填写 sessions.txt，或显式传入 --allow-all-sessions")
        return sorted({
            session.get("username") or ""
            for session in self.db.get_sessions(limit=500)
            if session.get("username")
        })

    def initialize_watermarks(self, sessions: list[str]) -> None:
        changed = False
        with self.state_lock:
            watermarks = self.state["watermarks"]
            missing = [username for username in sessions if username not in watermarks]
        for username in missing:
            messages = self.db.get_messages(username, limit=1)
            latest = int(messages[0].get("sort_seq") or 0) if messages else 0
            with self.state_lock:
                self.state["watermarks"][username] = latest
                self.state["watermarkLocalIds"][username] = int(messages[0].get("local_id") or 0) if messages else 0
            changed = True
            logging.info("会话新消息基线已建立 session=%s sortSeq=%d", username, latest)
        if changed:
            self.save_state()

    def poll_session(self, username: str) -> None:
        with self.state_lock:
            since = int(self.state["watermarks"].get(username, 0))
            since_local_id = int(self.state["watermarkLocalIds"].get(username, 0))
        messages = self.db.get_new_messages(
            username,
            since_seq=since,
            since_local_id=since_local_id,
        )
        for message in messages:
            if self.stop_event.is_set():
                return
            message["username"] = username
            try:
                self.on_message(message, None)
            except Exception as exc:
                # Do not acknowledge this or any later message. The next poll
                # retries from the last durably-processed sort_seq.
                logging.warning(
                    "新消息处理失败，保留游标等待重试 session=%s localId=%s error=%s",
                    username,
                    message.get("local_id"),
                    exc,
                )
                return
            with self.state_lock:
                self.state["watermarks"][username] = int(message.get("sort_seq") or since)
                self.state["watermarkLocalIds"][username] = int(message.get("local_id") or 0)
            self.save_state()

    def poll_sessions(self, sessions: list[str]) -> None:
        for username in sessions:
            try:
                self.poll_session(username)
            except Exception as exc:
                # WeChat may rotate a WAL or replace a shard while it is being
                # read. Keep the acknowledged cursor unchanged and retry the
                # session during the next polling cycle.
                logging.warning("会话轮询失败，下一轮自动重试 session=%s error=%s", username, exc)

    def touch_heartbeat(self) -> None:
        path = self.args.heartbeat
        os.makedirs(os.path.dirname(path), exist_ok=True)
        try:
            os.utime(path, None)
        except FileNotFoundError:
            with open(path, "ab"):
                pass

    def heartbeat_loop(self) -> None:
        while not self.stop_event.is_set():
            try:
                self.touch_heartbeat()
            except OSError as exc:
                logging.warning("监听器心跳写入失败 error=%s", exc)
            self.stop_event.wait(2.0)

    def backfill(self) -> None:
        if self.args.backfill <= 0:
            logging.info("历史补扫已关闭，仅处理监听启动后收到的新消息")
            return
        sessions = self.db.get_sessions(limit=500)
        if self.sessions:
            sessions = [session for session in sessions if (session.get("username") or "") in self.sessions]
        logging.info("启动历史补扫 sessions=%d perSession=%d", len(sessions), self.args.backfill)
        found = 0
        for session in sessions:
            username = session.get("username") or ""
            messages = self.db.get_messages(username, limit=self.args.backfill)
            for message in reversed(messages):
                if message.get("type") != "文件/链接/卡片":
                    continue
                row = self.db.get_message_row(username, message["local_id"])
                if not row:
                    continue
                card = extract_finder_video_card(row)
                if card is not None:
                    card["sourceSession"] = username
                    found += 1
                    self.submit(card)
        logging.info("历史补扫完成 finderVideos=%d", found)

    def retry_pending(self) -> None:
        with self.state_lock:
            pending = [dict(value) for value in self.state["pending"].values()]
        due = []
        now = int(time.time())
        for value in pending:
            card = dict(value.get("card") or {})
            source_session = str(card.get("sourceSession") or "").strip()
            if self.sessions and source_session not in self.sessions:
                continue
            attempts = max(0, int(value.get("attempts", 0)))
            delay = min(3600, max(60, 15 * (2 ** min(attempts, 8))))
            if now - int(value.get("lastAttemptAt", 0)) >= delay:
                due.append(card)
        if due:
            logging.info("重试到期待处理卡片 count=%d", len(due))
        for card in due:
            if card.get("objectId") and not self.stop_event.is_set():
                self.submit(card)

    def check_accepted(self) -> None:
        with self.state_lock:
            accepted = [(object_id, dict(value)) for object_id, value in self.state["accepted"].items()]
        for object_id, value in accepted:
            card = value.get("card") or {}
            source_session = str(card.get("sourceSession") or "").strip()
            if self.sessions and source_session not in self.sessions:
                with self.state_lock:
                    self.state["accepted"].pop(object_id, None)
                continue
            if self.stop_event.is_set():
                return
            try:
                status = self.api_media_status(object_id)
            except (OSError, ValueError, RuntimeError, urllib.error.HTTPError) as exc:
                logging.warning("转写状态读取失败 objectId=%s error=%s", object_id, exc)
                continue
            stage = status.get("stage", "")
            if stage == "completed":
                with self.state_lock:
                    completed = self.state["accepted"].pop(object_id, value)
                    completed["stage"] = stage
                    completed["completedAt"] = int(time.time())
                    self.state["processed"][object_id] = completed
                logging.info("视频号下载转写完成 objectId=%s", object_id)
            elif stage == "error":
                card = value.get("card") or {}
                with self.state_lock:
                    self.state["accepted"].pop(object_id, None)
                    self.state["pending"][object_id] = {
                        "card": card,
                        "attempts": int(value.get("attempts", 0)) + 1,
                        "lastError": status.get("error") or status.get("message") or "media job failed",
                        "lastAttemptAt": int(time.time()),
                    }
                logging.warning("下载转写失败，已回到重试队列 objectId=%s error=%s", object_id, status.get("error") or status.get("message"))
            elif stage in {"idle", "downloaded"}:
                # Media jobs live in wx_insight process memory. If that process
                # restarts, an accepted job that was queued/downloading becomes
                # idle (or downloaded when only the MP4 survived). Keeping it in
                # accepted forever makes the worker look alive while the card is
                # never submitted again. Move it back to the durable retry queue.
                card = value.get("card") or {}
                reason = "wx_insight 重启后任务需要重新提交" if stage == "idle" else "视频已下载，继续补做转写"
                with self.state_lock:
                    self.state["accepted"].pop(object_id, None)
                    self.state["pending"][object_id] = {
                        "card": card,
                        "attempts": int(value.get("attempts", 0)) + 1,
                        "lastError": reason,
                        "lastAttemptAt": 0,
                    }
                logging.info("恢复中断任务 objectId=%s stage=%s", object_id, stage)

    def run(self) -> None:
        sessions = self.active_sessions()
        self.prune_unscoped_queues()
        self.backfill()
        self.initialize_watermarks(sessions)
        if self.sessions:
            logging.info("指定会话监听已启动 sessions=%s pollInterval=%.1fs", ",".join(sessions), self.args.poll_interval)
        else:
            logging.warning("已显式允许全会话监听 sessions=%d pollInterval=%.1fs", len(sessions), self.args.poll_interval)
        last_retry = 0.0
        heartbeat_thread = threading.Thread(
            target=self.heartbeat_loop,
            name="wx-inbox-heartbeat",
            daemon=True,
        )
        heartbeat_thread.start()
        try:
            while not self.stop_event.is_set():
                if self.args.allow_all_sessions and not self.sessions:
                    sessions = self.active_sessions()
                    self.initialize_watermarks(sessions)
                self.poll_sessions(sessions)
                now = time.monotonic()
                if now - last_retry >= self.args.retry_interval:
                    last_retry = now
                    self.check_accepted()
                    self.retry_pending()
                    self.save_state()
                self.stop_event.wait(self.args.poll_interval)
        finally:
            self.stop_event.set()
            heartbeat_thread.join(timeout=3)
            self.save_state()

    def stop(self, *_args) -> None:
        self.stop_event.set()


def parse_args(argv=None):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    parser = argparse.ArgumentParser(description="wx_insight 微信视频号转发监听器")
    parser.add_argument("--db-reader", default=os.path.join(script_dir, "vendor", "wechatauto_db.py"))
    parser.add_argument("--db-root", default=os.environ.get("WX_INSIGHT_WECHAT_DB_ROOT", os.path.expanduser(r"~\Documents\xwechat_files")))
    parser.add_argument("--account", default=os.environ.get("WX_INSIGHT_WECHAT_ACCOUNT", ""))
    parser.add_argument("--sessions", default=None, help="逗号分隔的会话 username 白名单")
    parser.add_argument("--allow-all-sessions", action="store_true", help="显式允许监听全部会话（默认禁止）")
    parser.add_argument("--api", default=os.environ.get("WX_INSIGHT_API", DEFAULT_API))
    parser.add_argument("--config", default=os.environ.get("WX_INSIGHT_CONFIG", os.path.join(script_dir, "config.yaml")))
    parser.add_argument("--state", default=os.path.join(script_dir, "data", "wechat-inbox-state.json"))
    parser.add_argument("--cache", default=os.path.join(script_dir, "data", "wechat-db-cache"))
    parser.add_argument("--log", default=os.path.join(script_dir, "logs", "wechat-inbox-worker.log"))
    parser.add_argument("--heartbeat", default=os.path.join(script_dir, "data", "worker-heartbeat"))
    parser.add_argument("--backfill", type=int, default=DEFAULT_BACKFILL, help="显式补扫每个会话的历史消息数；默认 0，仅处理新消息")
    parser.add_argument("--poll-interval", type=float, default=2.0)
    parser.add_argument("--retry-interval", type=float, default=60.0)
    parser.add_argument("--api-timeout", type=float, default=55.0)
    args = parser.parse_args(argv)
    if args.sessions is None:
        configured_sessions = ""
        sessions_file_found = False
        sessions_path = os.path.join(script_dir, "sessions.txt")
        try:
            with open(sessions_path, "r", encoding="utf-8-sig") as source:
                sessions_file_found = True
                configured_sessions = ",".join(
                    line.strip()
                    for line in source
                    if line.strip() and not line.lstrip().startswith("#")
                )
        except OSError:
            pass
        args.sessions = configured_sessions if sessions_file_found else os.environ.get("WX_INSIGHT_WECHAT_SESSIONS", "")
    return args


def configure_logging(path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    file_handler = RotatingFileHandler(path, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8")
    file_handler.setFormatter(formatter)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logging.basicConfig(level=logging.INFO, handlers=[file_handler, console_handler])


def main(argv=None) -> int:
    args = parse_args(argv)
    configure_logging(args.log)
    module = load_module(args.db_reader)
    worker = InboxWorker(args, module)
    signal.signal(signal.SIGINT, worker.stop)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, worker.stop)
    worker.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

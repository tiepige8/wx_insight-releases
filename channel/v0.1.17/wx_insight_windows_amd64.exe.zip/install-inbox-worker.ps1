﻿param(
    [string]$InstallRoot = $PSScriptRoot,
    [string]$Python = ''
)

$ErrorActionPreference = 'Stop'
$workerRoot = Join-Path $InstallRoot 'inbox-worker'
$worker = Join-Path $workerRoot 'wechat-channel-inbox-worker.py'
$sessionsPath = Join-Path $workerRoot 'sessions.txt'
$taskName = 'wx_insight_inbox_worker'

if ([string]::IsNullOrWhiteSpace($Python)) {
    $bundledPython = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python311\python.exe'
    if (Test-Path -LiteralPath $bundledPython) {
        $Python = $bundledPython
    }
}
if ([string]::IsNullOrWhiteSpace($Python) -or -not (Test-Path -LiteralPath $Python)) {
    $Python = (Get-Command python -ErrorAction Stop).Source
}
if (-not (Test-Path $worker)) {
    throw "worker is missing: $worker"
}
if (-not (Test-Path -LiteralPath $sessionsPath)) {
    throw '尚未配置监听会话：inbox-worker\sessions.txt。为避免监听全部微信对话，安装已停止。'
}
$configuredSessions = @(
    [System.IO.File]::ReadAllLines($sessionsPath, [System.Text.Encoding]::UTF8) |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ -and -not $_.StartsWith('#') }
)
if ($configuredSessions.Count -eq 0) {
    throw 'sessions.txt 没有有效会话，请至少填写一个 wxid_xxx。'
}

& $Python -c 'import cryptography, zstandard'
if ($LASTEXITCODE -ne 0) {
    throw "缺少 Python 依赖，请先运行：python -m pip install cryptography zstandard"
}

$arguments = '"' + $worker + '" --config "' + (Join-Path $InstallRoot 'config.yaml') + '"'
$action = New-ScheduledTaskAction -Execute $Python -Argument $arguments -WorkingDirectory $workerRoot
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 10 -RestartInterval (New-TimeSpan -Minutes 1) -MultipleInstances IgnoreNew
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Highest

Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force | Out-Null
Start-ScheduledTask -TaskName $taskName
Write-Host "WORKER_TASK_OK name=$taskName root=$workerRoot"

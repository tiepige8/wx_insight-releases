﻿param(
    [string]$InstallRoot = $PSScriptRoot,
    [string]$AppTaskName = 'wx_insight_app',
    [string]$WorkerTaskName = 'wx_insight_inbox_worker',
    [string]$DashboardURL = 'http://127.0.0.1:2025/insight',
    [switch]$NoBrowser
)

$ErrorActionPreference = 'Stop'

function Start-TaskIfStopped {
    param([Parameter(Mandatory = $true)][string]$Name)

    $task = Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue
    if ($null -eq $task) {
        return $false
    }
    if ($task.State -ne 'Running') {
        Start-ScheduledTask -TaskName $Name
    }
    return $true
}

try {
    $launchStartedAt = Get-Date
    $appStarted = Start-TaskIfStopped -Name $AppTaskName
    if (-not $appStarted) {
        # Compatibility with the current test installation on broll-win.
        $appStarted = Start-TaskIfStopped -Name 'wx_insight_interface_test'
    }
    if (-not $appStarted) {
        $exe = Join-Path $InstallRoot 'wx_channel.exe'
        if (-not (Test-Path -LiteralPath $exe)) {
            throw "找不到微信洞察主程序：$exe"
        }
        Start-Process -FilePath $exe -WorkingDirectory $InstallRoot -WindowStyle Hidden
    }

    $workerStarted = Start-TaskIfStopped -Name $WorkerTaskName
    if (-not $workerStarted) {
        throw "找不到视频号监听任务：$WorkerTaskName。请重新运行 install-windows-app.ps1。"
    }
    $heartbeat = Join-Path $InstallRoot 'inbox-worker\data\worker-heartbeat'
    $workerReady = $false
    for ($attempt = 0; $attempt -lt 60; $attempt++) {
        Start-Sleep -Seconds 1
        $workerTask = Get-ScheduledTask -TaskName $WorkerTaskName -ErrorAction SilentlyContinue
        $heartbeatFile = Get-Item -LiteralPath $heartbeat -ErrorAction SilentlyContinue
        if ($null -ne $workerTask -and $workerTask.State -eq 'Running' -and
            $null -ne $heartbeatFile -and $heartbeatFile.LastWriteTime -ge $launchStartedAt.AddSeconds(-5)) {
            $workerReady = $true
            break
        }
    }
    if (-not $workerReady) {
        throw "视频号监听器没有正常心跳，请查看 inbox-worker\logs\wechat-inbox-worker.log。"
    }

    $ready = $false
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        try {
            $response = Invoke-WebRequest -UseBasicParsing -Uri $DashboardURL -TimeoutSec 2
            if ($response.StatusCode -eq 200) {
                $ready = $true
                break
            }
        }
        catch {
            Start-Sleep -Seconds 1
        }
    }
    if (-not $ready) {
        throw '后台服务在 30 秒内没有就绪，请查看 logs\wx_channel.log。'
    }
    if (-not $NoBrowser) {
        Start-Process $DashboardURL
    }
}
catch {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show(
        $_.Exception.Message,
        '微信洞察启动失败',
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Error
    ) | Out-Null
    exit 1
}
